﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aplicatie01
{
    /*Fie A o mulțime de n numere întregi, nu neapărat distincte. 
     * Se cere determinare unei submulțimi B, cu m elemente, m<=n, 
     * astfel încât suma elementelor selectate să fie maximă.
 
     */
    class Program
    {
        static void Main(string[] args)
        {
            int n, m;
            List<int> multimeA = new List<int>();
            List<int> multimeB = new List<int>();
            Console.Write("n=");
            n = int.Parse(Console.ReadLine());
            Console.Write("m=");
            m = int.Parse(Console.ReadLine());
            //Completarea multimii A cu valori aleatorii
            Random el = new Random();
            for (int i = 0; i < n; i++)
            {
                multimeA.Add(el.Next(-100,100));
            }
            //Afisare la ecran a multimii A
            Console.WriteLine("Elementele multimii A:");
            Afisare(multimeA);
            
            int s=0;
            SolutieGreedy(multimeA, n, ref multimeB, m, ref s);
            
            //Afisarea la ecran a multimii nou formate si a sumei
            Console.WriteLine("\nElementele multimii B:");
            Afisare(multimeB);
            
            Console.WriteLine("\n sumaMaxima = {0}", s);
            Console.ReadKey();
        }

        private static void Afisare(List<int> multime)
        {
            foreach (int item in multime)
            {
                Console.Write("{0} ", item);
            }
        }

        private static void SolutieGreedy(List<int> multimeA, int n, ref List<int> multimeB, int m, ref int s)
        {
            //Sortarea multimii A in ordine crescatoare
            multimeA.Sort();
            //Dupa care are loc sortarea descrescatoare
            multimeA.Reverse();
            s = 0;
            //adaugam in multimea B primele m elemente si calculam suma lor
            for (int i = 0; i < m; i++)
            {
                multimeB.Add(multimeA[i]);
                s += multimeB[i];
            }
        }
    }
}
