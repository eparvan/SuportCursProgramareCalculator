﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StivaInversareSir
{
    class Program
    {
        /*Să se scrie funcţia de inversare a unui şir folosind o stivă alocată dinamic
         */
        static void Main(string[] args)
        {
            
            string sirul;
            
            Console.Write("Introdu sirul: ");
            sirul = Console.ReadLine();
            Console.WriteLine("Ati introdus sirul: {0}", sirul);
            Console.WriteLine("Sirul inversat este: {0}", InversareSir(sirul));
            
            Console.ReadKey();
        }

        //Funcția de inversare a unui sir de caractere cu ajutorul stivei
        public static string InversareSir(string sir)
        {
            Stack<char> stiva = new Stack<char>();
            string sirInversat = "";
            //Parcurgem sirul și depunem caracterele pe stivă
            for (int i = 0; i < sir.Length; i++)
            {
                stiva.Push(sir[i]);
            }
            //Parcurgem stivă și preluăm carcterele, formînd șirul nou
            while (stiva.Count > 0)
            {
                sirInversat += stiva.Pop();
            }
            return sirInversat;
        }
    }
}
