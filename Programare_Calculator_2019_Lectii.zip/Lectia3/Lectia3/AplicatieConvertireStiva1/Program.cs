﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AplicatieConvertireStiva1
{
    class Program
    {
        /*
         * citeşte de la tastatură un număr natural n 
         * şi afişează numărul biţilor din reprezentarea 
         * lui n în baza 2, apoi afişează biţii lui n.
         */
        static void Main(string[] args)
        {
            int n, num;
            Stack<int> stiva = new Stack<int>(); //Declarăm stiva
            Console.Write("n = ");
            n = int.Parse(Console.ReadLine());
            num = n; //memorăm numarul initial
            // depun bitii lui n in stiva (resturile de la impărțirea la 2)
            while (n > 0)
            {
                stiva.Push(n % 2);
                n = n / 2;
            }
            Console.WriteLine("Numarul {0} convertit in baza 2 are {1} biti.", num, stiva.Count);
            // scot bitii de pe stiva
            Console.Write("Numarul {0} convertit in baza 2 este :", num);
            while (stiva.Count > 0)
            {
                Console.Write(stiva.Peek());
                stiva.Pop(); //stergem elementul din stivă
            }
            Console.ReadKey();
        }
    }
}
