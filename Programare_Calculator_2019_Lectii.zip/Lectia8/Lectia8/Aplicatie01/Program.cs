﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aplicatie01
{
    /*
     * Se consideră numerele naturale din mulțimea  {0, 1, 2, .....,n}. 
     * Elaborați  un program care  determină cîte numere K din această mulțime  
     * suma cifrelor fiecărui număr este egală cu m.  
     * În particular, pentru  n=100 și  m=2, în  mulțimea {0,1,2,...,100} 
     * există 3 numere care  satisfac condițiile problemei: 2, 11, 20. Prin  urmare, K=3.

     */
    class Program
    {
        static void Main(string[] args)
        {
            int n;
            int valoare;
            Console.Write("n=");
            n = int.Parse(Console.ReadLine());
            Console.Write("valoare=");
            valoare = int.Parse(Console.ReadLine());
            int cantitate=0;
            for (int i = 0; i < n; i++)
            {
                if (Solutie(i, valoare))
                {
                    Prelucrare(i, ref cantitate);
                }
            }
            Console.WriteLine("\n Astfel de numere sunt:{0}", cantitate);
            Console.ReadKey();
        }

        private static void Prelucrare(int i, ref int cantitate)
        {
            Console.WriteLine("Numarul={0}", i);
            cantitate++;
        }

        private static bool Solutie(int i, int valoare)
        {
            if (Suma(i)==valoare)
            {
                return true;
            }
            return false;
        }

        private static int Suma(int i)
        {
            int s = 0;
            while (i!=0)
            {
                s = s + (i % 10);
                i /= 10;
            }
            return s;
        }
    }
}
