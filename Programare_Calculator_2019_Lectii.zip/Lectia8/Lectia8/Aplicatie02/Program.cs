﻿using System;
using System.IO;

namespace Aplicatie02
{
    /*Să se scrie un program care determină toate secvenţele binare de lungime n, 
     * fiecare din ele conţinînd nu mai puţin de k cifre de 1.
        Intrare: numere naturale n, 1<n<20, şi k, k<n, se citesc de la tastatură.
        Ieşire: fiecare linie a fişierului text OUT.TXT va conţine câte o secvenţă 
        binară distinctă, ce corespunde condiţiilor din enunţul problemei.

     */
    class Program
    {
        const int nmax = 20;
        public static int[] b = new int[nmax];
        public static int n, k;

        static void Main(string[] args)
        {
            //Deschidem fisierul pentru scriere
            using (StreamWriter fout = new StreamWriter("date.out"))
            {
                fout.WriteLine("Solutiile obtinute:");
            }
            int r;
            Console.Write("n=");
            n = int.Parse(Console.ReadLine());
            Console.Write("k=");
            k = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                b[i] = 0;
            }
            do
            {
                r = Numara();
                if (r==k)
                {
                    Scrie();
                }
                if (r<n)
                {
                    Urmator(b);
                }
            } while (r!=n);
        }

        private static void Urmator(int[] x)
        {
            int j = n;
            while (x[j]==1)
            {
                x[j] = 0;
                j--;
            }
            x[j] = 1;
        }

        private static void Scrie()
        {
            using (StreamWriter fout = new StreamWriter("date.out", append:true))
            {
                for (int i = 1; i <= n; i++)
                {
                    fout.Write("{0}", b[i]);
                }
                fout.WriteLine();
                
            }
        }

        private static int Numara()
        {
            int s = 0;
            for (int i = 1; i <= n; i++)
            {
                s += b[i];
            }
            return s;
        }
    }
}
