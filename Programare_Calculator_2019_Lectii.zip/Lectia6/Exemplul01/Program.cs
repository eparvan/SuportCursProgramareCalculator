﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace Exemplul01
{
    /*Determinarea timpului de executie
     */
    class Program
    {
        static void Main(string[] args)
        {
            Stopwatch stw = new Stopwatch();
            stw.Start(); //startul algoritmului
            //algoritmul propriu zis
            int n = 100000;
            double s = 0;
            double[,] t = new double[n,n];
            Random el = new Random();
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j <n ; j++)
                {
                    t[i, j] = el.Next(100);
                    s = s + t[i, j];
                }
              
            }
            stw.Stop();//sfirsitul algoritmului
            TimeSpan ts = stw.Elapsed;
            string elapsedTime = String.Format("{0:00}:{1:00}:{2:00}.{3:00}", 
                ts.Hours,ts.Minutes, ts.Seconds, ts.Milliseconds/10);
            Console.WriteLine("Timpul de executie erste: "+ elapsedTime);
            Console.ReadKey();
        }
    }
}
