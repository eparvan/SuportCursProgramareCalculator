﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ArboriBinari
{
    //Structura nodului arborelui binar: Value - valoarea nodului, RightNode - adresa nodului din dreapta,
    //LeftNode - adresa nodului din stinga
    class Node
    {
        public int Value { get; set; }  //valoarea nodului
        public Node RightNode { get; set; } //nodul sting

        public Node LeftNode { get; set; } //nodul drept

        public Node(int value) //constructorul nodului
        {
            this.Value = value;
        }
        //Metoda pentru afisarea structurii arborelui
        public void PrintPretty(string indent, bool last)
        {

            Console.Write(indent);
            if (last)
            {
                Console.Write("└─");
                indent += "  ";
            }
            else
            {
                Console.Write("├─");
                indent += "| ";
            }
            Console.WriteLine(Value);

            var children = new List<Node>();//adaugarea elementor arborelui binar intr-o lista unidirectionala
            if (this.LeftNode != null)
                children.Add(this.LeftNode);
            if (this.RightNode != null)
                children.Add(this.RightNode);

            for (int i = 0; i < children.Count; i++)
                children[i].PrintPretty(indent, i == children.Count - 1);

        }
    }
}
