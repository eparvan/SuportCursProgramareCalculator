﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ArboriBinari
{
    class Tree
    {
        public Node root; //radacina arborelui binar
        public Tree() //constructorul arborelui binar
        {
            root = null;
        }
        public Node ReturnRoot() //obtinerea nodului radacina
        {
            return root;
        }
        public void Print() // apelarea metodei pentru tiparirea la ecran a structurii arborelui binar
        {
            root.PrintPretty("", true);
        }
        //Metoda de adaugare a elementelor in arborele binar
        public void Insert(int id)
        {
            Node newNode = new Node(id);//Crearea nodului cu valoarea id
            newNode.Value = id;
            if (root == null) //Daca elemente in arbore inca nu sint, atunci el este radacina
                root = newNode;
            else
            {
                //altfel se adauga in stinga sau in dreapta nodului radacina
                Node current = root;
                Node parent;
                while (true)
                {
                    parent = current;
                    if (id < current.Value)  ///adaugam elementul in stinga 
                    {
                        current = current.LeftNode;
                        if (current == null)
                        {
                            parent.LeftNode = newNode;
                            return;
                        }
                    }
                    else
                    {
                        current = current.RightNode;
                        if (current == null) // adaugam elementul in dreapta
                        {
                            parent.RightNode = newNode;
                            return;
                        }
                    }
                }
            }

        }
        
        //parcurgerea arborelui in preordine
        public void PreOrder(Node Root)
        {
            if (Root != null)
            {
                Console.Write(Root.Value + " ");
                PreOrder(Root.LeftNode);
                PreOrder(Root.RightNode);
            }
        }
        //parcurgerea arborelui in inordine
        public void InOrder(Node Root)
        {
            if (Root != null)
            {
                InOrder(Root.LeftNode);
                Console.Write(Root.Value + " ");
                InOrder(Root.RightNode);
            }
        }

        //parcurgerea arborelui in postordine
        public void PostOrder(Node Root)
        {
            if (Root != null)
            {
                PostOrder(Root.LeftNode);
                PostOrder(Root.RightNode);
                Console.Write(Root.Value + " ");
            }
        }

    }
}
