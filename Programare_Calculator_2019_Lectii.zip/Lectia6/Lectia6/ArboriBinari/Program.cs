﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ArboriBinari
{
    class Program
    {
        static void Main(string[] args)
        {
            Tree arbore = new Tree(); //Crearea arborelui
            //Adaugarea elementor in arbore
            arbore.Insert(23); //radacina
            arbore.Insert(55);//nodul din dreapta lui 23
            arbore.Insert(11);//nodul din stinga lui 23
            arbore.Insert(27);//nodul din stinga lui 55
            arbore.Insert(4);//nodul din stinga lui 11
            arbore.Insert(3);//nodul din stinga lui 4
            arbore.Insert(19);//nodul din dreapta lui 11
            arbore.Insert(22);//nodul din dreapta lui 19

            Console.WriteLine("Arborele initial:");
            arbore.Print(); //Afisarea structurii arborelui initial
            //Afisare parcurgerii elementelor arborelui in preordine (RSD)
            Console.WriteLine("PreOrdine");
            arbore.PreOrder(arbore.ReturnRoot()); //arbore.ReturnRoot() - nodul radacina al arborelui 
            Console.WriteLine(Environment.NewLine);
            //Afisare parcurgerii elementelor arborelui in postordine (SDR)
            Console.WriteLine("PostOrdine");
            arbore.PostOrder(arbore.ReturnRoot());
            Console.WriteLine(Environment.NewLine);
            //Afisare parcurgerii elementelor arborelui in iordine (SRD)
            Console.WriteLine("InOrdine");
            arbore.InOrder(arbore.ReturnRoot());
            Console.WriteLine(Environment.NewLine);


            Console.ReadLine();
        }

        
    }
}

