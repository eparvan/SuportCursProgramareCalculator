﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EvaluareExpresiiAritmetice
{
    /*
     * Se consideră expresiile aritmetice formate din operanzi și operatorii binari +, -, *, /. 
     * Operanzii sînt variabile numele cărora este format dintr-o singură literă și constante alcătuite dintr-o cifră. 
     * Fiecărei expresii aritmetice i se poate asocia un arbore binar după cum urmează: 
     * a) expresiei aritmetice formate dintr-un singur operand i se asociază un arbore binar format doar 
     * din nodul ce conţine operandul respectiv; 
     * b) expresiei aritmetice de forma E1°E2, unde E1 și E2 sînt expresii aritmetice, 
     * i se asociază un arbore binar care are în nodul-rădăcină operatorul °, 
     * ca subarbore stîng arborele asociat expresiei E1, iar ca subarbore drept arborele asociat expresiei E2. 
     * Valoarea expresiei se calculează efectuînd operaţia din nodul-rădăcină asupra valorilor subexpresiilor 
     * reprezentate de subarborele stîng și subarborele drept. 
     * Scrieţi un program care: 
     * a) construiește arbori binari asociaţi expresiilor aritmetice citite de la tastatură;
     * b) evaluează expresiile aritmetice reprezentate prin arborii binari. 
     * Indicaţie. Algoritmul va urma defi niţia recursivă a arborelui în studiu.
     * Ca operator curent „°” se poate desemna orice operator +, - din expresia supusă prelucrării. 
     * Operatorii *, / pot fi  desemnaţi ca operatori curenţi numai cînd expresia supusă prelucrării nu conţine
     */
    // Node Class: Baza pentru arborele binar, păstrează datele pentru nodurile stânga și dreapta.
    class Node
    {
        // Se va folosi stiva pentru rezolvarea expresiei din arbore
        private Stack<string> stack = new Stack<string>();

        // Rezolvarea expresiei
        public int Solve()
        {
            /* Această metodă utilizează o stivă pentru a rezolva expresia. 
             * Notarea postfix este tokenizat și adăugată sistematic în stivă.
             * Când stiva întâlnește o operație, ea se execută și modifică conținutul pe stivă. 
             * Elementul final lăsat pe stivă (dat fiind expresia a fost validă) va fi si răspunsul.
             */
            string a, b; // Variabile temporare pentru pastrarea valorilor
            string[] tokens = Postfix().Split(' '); // Tokenizarea expresiei aritmetice
            foreach (string e in tokens)
            {
                switch (e)
                {
                    /* Evaluarea expresiei dupa operatie
                     */
                    case "+":
                        b = stack.Pop();
                        a = stack.Pop();
                        stack.Push(Convert.ToString(Convert.ToInt16(a) + Convert.ToInt16(b)));
                        break;
                    case "-":
                        b = stack.Pop();
                        a = stack.Pop();
                        stack.Push(Convert.ToString(Convert.ToInt16(a) - Convert.ToInt16(b)));
                        break;
                    case "/":
                        b = stack.Pop();
                        a = stack.Pop();
                        stack.Push(Convert.ToString(Convert.ToInt16(a) / Convert.ToInt16(b)));
                        break;
                    case "*":
                        b = stack.Pop();
                        a = stack.Pop();
                        stack.Push(Convert.ToString(Convert.ToInt16(a) * Convert.ToInt16(b)));
                        break;
                    case "%":
                        b = stack.Pop();
                        a = stack.Pop();
                        stack.Push(Convert.ToString(Convert.ToInt16(a) % Convert.ToInt16(b)));
                        break;
                    default:
                        stack.Push(e);
                        break;
                }
            }
            // Valoarea  expresiei
            return Convert.ToInt16(stack.Pop());
        }

        // Returnarea notatiei prefixa a expresiei
        public string Prefix()
        {
            /* 
             */
            string res = this.Value + " ";
            if (this.left != null) 
            {
                res += this.left.Prefix();
                res += this.right.Prefix();
            }
            return res;
        }

        // Returnarea notatiei postfixa a expresiei
        public string Postfix()
        {
            /* 
             */
            string res = "";
            if (this.left != null) // 
            {
                res += this.left.Postfix() + " ";
                res += this.right.Postfix() + " ";
            }
            res += this.Value;
            return res;
        }

        // 
        public string Infix()
        {
            
            string res = "";
            if (this.left != null)
            {
                res = res + "(" + left.Infix() + " " + Value + " " + right.Infix() + ")";
            }
            else
            {
                res += Value;
            }
            return res;
        }

        // Constructorul pentru subnoduri
        public Node(char op, Node l, Node r)
        {
            left = l;
            right = r;
            Value = op.ToString();
        }
        // Constructor pentru noduri de frunze
        public Node(string value)
        {
            
            left = null;
            right = null;
            Value = value;
        }

        // Nodul din stinga
        private Node left;
        // Nodul din dreapta
        private Node right;
        // Valoare
        private string Value;
    }

    // Programul:
    class Program
    {
        /* Expresia:
         * (((1-2)-3) + (4*(5+6)))
         *        +
         *      /   \
         *     -     *
         *    / \   / \
         *   -   3 4   +
         *  / \       / \
         * 1   2     5   6
        */

        static void Main(string[] args)
        {
            Node root = new Node('+', new Node('-', new Node('-', new Node("1"), 
                new Node("2")), new Node("3")),
                                      new Node('*', new Node("4"), 
                                      new Node('+', new Node("5"), new Node("6"))));
            Console.WriteLine("Notatia prefixa: \t" + root.Prefix());
            Console.WriteLine("Notatia postfixa: \t" + root.Postfix());
            Console.WriteLine("Notatia infixa: \t" + root.Infix());
            Console.WriteLine("Rezultatul expresiei este :\t" + root.Solve());
            Console.ReadKey(true);
        }
    }
}
