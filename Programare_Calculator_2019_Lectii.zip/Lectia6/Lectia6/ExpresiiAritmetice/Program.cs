﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExpresiiAritmetice
{
    /* 
     */
    public class Node
    {
        public char Value;
        public Node Left;
       public  Node Right;
       public  Node (char item)
        {
            Value = item;
            Left = Right = null;
        }
    }
    class ExpressionTree
    {
        bool IsOperator(char c)
        {
            if (c=='+' || c=='-' || c=='*' ||c=='/')
            {
                return true;
            }
            return false;
        }
        public void Inorder(Node t)
        {
            if (t != null)
            {
                Inorder(t.Left);
                Console.Write(t.Value + " ");
                Inorder(t.Right);
            }
        }
        public  Node ConstructTree(char[] postfix)
        {
            Stack<Node> st = new Stack<Node>();
            Node t, t1, t2;
            for (int i = 0; i < postfix.Length; i++)
            {
                if (!IsOperator(postfix[i]))
                {
                    t = new Node(postfix[i]);
                    st.Push(t);
                }
                else
                {
                    t = new Node(postfix[i]);
                    t1 = st.Pop();
                    t2 = st.Pop();
                    t.Right = t1;
                    t.Left = t2;
                    st.Push(t);
                }

            }
            t = st.Peek();
            st.Pop();
            return t;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            ExpressionTree et = new ExpressionTree();
            string postfix = "ab+ef*g*-";
            Console.Write("Expresia initiala:");
            Console.WriteLine(postfix);
            char[] masivCaractere = postfix.ToCharArray();
            Node root = et.ConstructTree(masivCaractere);
            Console.WriteLine("Expresia in notatia infix:\n");
            et.Inorder(root);
            Console.ReadKey();

        }
    }
}
