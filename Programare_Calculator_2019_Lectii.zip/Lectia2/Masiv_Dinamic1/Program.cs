﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Masiv_Dinamic1
{
    /*Este dat un masiv unidimensional cu 10 elemente intregi generate aleator, 
     * sa se adauge la începutul masivului elementul maxim și la sfîrșitul 
     * masivului elementul minim
     */
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList tabel1 = new ArrayList();
            ArrayList tabel2 = new ArrayList();
            Random element = new Random();
            for (int i = 0; i < 10; i++)
            {
                tabel1.Insert(i, element.Next(1,100));
            }

            Console.WriteLine("Tabelul initial:\n");
            foreach(int el in tabel1)
            {
                Console.Write("{0} ", el);
            }
            tabel2 = tabel1;
            tabel1.Sort();
            int indMaxim = (int)tabel1.Count-1;
            int max = (int)tabel1[indMaxim];
            int min = (int)tabel1[0];
            Console.WriteLine("\nElementul maximal: {0}", max);
            Console.WriteLine("\nElementul minimal: {0}", min);

            //Adaugarea elementelor

            tabel2.Insert(0, max);
            tabel2.Insert(indMaxim+2, min);
            Console.WriteLine("Tabelul modificat:\n");
            foreach (int el in tabel2)
            {
                Console.Write("{0} ", el);
            }
            Console.ReadKey();

        }
    }
}
