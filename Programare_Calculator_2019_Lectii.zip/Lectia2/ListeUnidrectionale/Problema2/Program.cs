﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problema2
{
    class Program
    {
        /*Să se determine suma și media aritmetică a elementelor într-o listă unidirecțională
         */
        static void Main(string[] args)
        {
            List<int> numbersList = new List<int>() { 6, 7, 5, 9, 6  };
            int suma = 0;
            foreach(int el in numbersList)
            {
                suma += el;
            }

            float media = (float)suma / numbersList.Count;
            Tiparestelista(numbersList);
            Console.WriteLine("Media={0}", media);
            Console.ReadKey();
        }

        private static void Tiparestelista(List<int> lista)
        {
            Console.WriteLine("\n Total elemente: {0} \n", lista.Count);
            Console.WriteLine("\n Elementele listei: \n");
            foreach (int i in lista)
            {
                Console.Write("{0}  ", i);
            }
        }
    }
}
