﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListeUnidrectionale
{
    /*
     De la tastatura se citesc un sir de numere intregi.
     Ele se vor introduce intr-o lista unidirectionala.
     Sa se afiseze elementele listei la ecran.
         */
    class Program
    {
        static void TiparesteLista(List<int> lista)
        {
            Console.WriteLine("\n Total elemente: {0} \n", lista.Count);
            Console.WriteLine("\n Elementele listei: \n");

            //Parcurgerea elementelor listei poate fi făcută cu instrucțiunea foreach
            foreach (int i in lista)
            {
                Console.Write("{0}  ", i);
            }

        }
        static void Main(string[] args)
        {
            List<int> numbersList = new List<int>(); // { -45, 24, 12, -13, 11, 5, 7, 30, 44};

            //Citirea elementelor listei de la tastatură
            //---------------------------------------------------------------------
            int element;
            char prelungire = 'D';
            do
            {
                Console.Write("Introdu elementul listei: ");
                element = int.Parse(Console.ReadLine());
                numbersList.Add(element);
                Console.WriteLine("\n Mai introduceti elemente in lista? D/N");
                prelungire = char.Parse(Console.ReadLine());
            }
            while (prelungire == 'D');
            //---------------------------------------------------------------------
            TiparesteLista(numbersList);

           // Divizarea listei in doua liste: numerePare, numereImpare
            List<int> numerePare = new List<int>();
            List<int> numereImpare = new List<int>();
            foreach (int i in numbersList)
            {
                if (i % 2 == 0) numerePare.Add(i);
                else
                    numereImpare.Add(i);
            }
            Console.WriteLine("\nLista cu numere impare:");
            TiparesteLista(numereImpare);
            Console.WriteLine("\nLista cu numere pare:");
            TiparesteLista(numerePare);
            List<int> listaSortata = new List<int>();
            listaSortata = numbersList;
            listaSortata.Sort();
            Console.WriteLine("\nLista cu numere sortata crescator:");
            TiparesteLista(listaSortata);
            Console.WriteLine("\nSortare descrescator:\n");
            listaSortata.Reverse();
            TiparesteLista(listaSortata);
            // Excluderea elementelor negative, este folosit operatorul expresiei lambda =>
            Console.WriteLine("Lista fara elemente negative:");
            numbersList.RemoveAll(i => i < 0); 
            TiparesteLista(numbersList);

            Console.ReadKey();
        }
    }
}
