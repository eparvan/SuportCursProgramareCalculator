﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExempleListe1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Listă de numere întregi
            List<int> listaNotelor = new List<int>() { 5, 6, 4, };

            //Lista de persoane
            List<string> listaPersoanelor = new List<string> { "Popa", "Acciu", "Raru" };

        }
    }
}
