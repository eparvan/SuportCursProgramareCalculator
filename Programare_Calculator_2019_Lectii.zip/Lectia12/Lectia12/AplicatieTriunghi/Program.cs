﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Diagnostics;

namespace AplicatieTriunghi
{
    class Program
    {
        public static void Main(string[] args)
        {
            BruteForce();
            Dynamic();
            Console.ReadKey();
        }


        public static void BruteForce()
        {
            Console.WriteLine("Algoritmul BrutForse\n");
            Stopwatch clock = Stopwatch.StartNew();
            string filename ="input.txt";
            int[,] inputTriangle = readInput(filename);

            int posSolutions = (int)Math.Pow(2, inputTriangle.GetLength(0) - 1);
            int largestSum = 0;
            int tempSum, index;

            for (int i = 0; i <= posSolutions; i++)
            {
                tempSum = inputTriangle[0, 0];
                index = 0;
                for (int j = 0; j < inputTriangle.GetLength(0) - 1; j++)
                {
                    index = index + (i >> j & 1);
                    tempSum += inputTriangle[j + 1, index];
                }

                if (tempSum > largestSum)
                {
                    largestSum = tempSum;
                }
            }
            clock.Stop();
            Console.WriteLine("Suma maximala in triunghi este egala cu: {0}", largestSum);
            Console.WriteLine("Solutia a fost calculata in {0} ms", clock.ElapsedMilliseconds);
            Console.WriteLine("-------------------------------------------------------------------");           
        }


        public static void Dynamic()
        {
            Console.WriteLine("\nAlgoritmul Programare Dinamica\n");
            Stopwatch clock = Stopwatch.StartNew();            
            string filename = "input.txt";
            int[,] inputTriangle = readInput(filename);
            int lines = inputTriangle.GetLength(0);
            int[] largestValues = new int[lines];

            //Initialise the algorithm
            for (int i = 0; i < lines; i++)
            {
                largestValues[i] = inputTriangle[lines - 1, i];
            }

            for (int i = lines - 2; i >= 0; i--)
            {
                for (int j = 0; j <= i; j++)
                {
                    largestValues[j] = inputTriangle[i, j] + Math.Max(largestValues[j], largestValues[j + 1]);
                }
            }

            clock.Stop();
            Console.WriteLine("Suma maximala in triunghi este egala cu: {0}", largestValues[0]);
            Console.WriteLine("Solutia a fost calculata in {0} ms", clock.ElapsedMilliseconds);
           
        }


        private static  int[,] readInput(string filename)
        {
            string line;
            string[] linePieces;
            int lines = 0;
            StreamReader r = new StreamReader(filename);
            while ((line = r.ReadLine()) != null)
            {
                lines++;
            }
            int[,] inputTriangle = new int[lines, lines];
            r.Close();
           
            StreamReader f = new StreamReader(filename);

            int j = 0;
            Console.WriteLine("Triunghiul initial:");
            while ((line = f.ReadLine()) != null)
            {
                linePieces = line.Split(' ');
                for (int i = 0; i < linePieces.Length; i++)
                {
                   inputTriangle[j, i] = int.Parse(linePieces[i]);
                    Console.Write("{0} ", linePieces[i]);
                }
                j++;
                Console.WriteLine();
            }
            f.Close();
            return inputTriangle;
        }

    }
}
