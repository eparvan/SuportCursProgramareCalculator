﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AplicatiaMonede
{
    /*Este data o sumă de bani S, și o cantitate infinită de monezi cu 
     * valorile date V={V1, V2, V3, ..., Vm}.
     * Determinați numărul minim de monede pentru schimbul sumei S.
     */
    class Program
    {
        static void Main(string[] args)
        {
            //Valorile monedelor
            int[] monede = { 1, 2, 5, 10, 20, 50, 100};
            int m = monede.Length;
            //Suma necesara de schimbat
            Console.Write("Suma necesara de schimbat:");
            int suma = int.Parse(Console.ReadLine());
            Console.WriteLine("Pentru suma={0} minimum sint necesare {1} monede.", suma, MinimMonede(monede, m, suma));
            Console.ReadKey();
        }

        private static int MinimMonede(int[] monede, int m, int suma)
        {
            //table[i] - va stoca numărul minim de monede necesare pentru valoarea i.
            // Atunci table[suma] - rezultatul cautat
            int[] table = new int[suma+1];
            table[0] = 0; //Cazul de baza
            //Initializa elementele tabelului table cu valori infinite
            for (int i = 1; i <= suma; i++)
            {
                table[i] = int.MaxValue;
            }
            //Calculam minimul de monede necesare pentru toate valorile de la 1 la suma
            for (int i = 1; i <= suma; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    if (monede[j]<=i)
                    {
                        int sub_res = table[i - monede[j]];
                        if (sub_res !=int.MaxValue && sub_res+1 < table[i])
                        {
                            table[i] = sub_res + 1;
                        }
                    }
                }
            }
            return table[suma];
        }
    }
}
