﻿using System;

namespace AplicatieCombinari
{
    /*Combinarile de n luate cite k
     */
    class Program
    {
        static int n, k;
        static int[] st = new int[20];
        static void Main(string[] args)
        {
            Console.Write("n=");
            n = int.Parse(Console.ReadLine());
            Console.Write("k=");
            k = int.Parse(Console.ReadLine());
            st[0] = 0;
            Bkt(1);
        }

        private static void Bkt(int p)
        {
            for (int val = st[p-1]+1; val <= n; val++)
            {
                st[p] = val;
                if (Solutie(p))
                {
                    Tipar(p);
                }
                else
                {
                    Bkt(p + 1);
                }
            }
        }

        private static void Tipar(int p)
        {
            for (int i = 1; i <= p; i++)
            {
                Console.Write("{0} ", st[i]);
            }
            Console.WriteLine();
        }

        private static bool Solutie(int p)
        {
            if (k==p)
            {
                return true;
            }
            else 
                return false;
        }
    }
}
