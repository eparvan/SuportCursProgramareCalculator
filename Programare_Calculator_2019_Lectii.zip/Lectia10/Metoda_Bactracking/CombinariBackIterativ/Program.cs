﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Runtime.InteropServices.WindowsRuntime;

namespace CombinariBackIterativ
{
    class Program
    {
        static int n, k;
        static int[] st = new int[20];
        static void Main(string[] args)
        {
            Console.Write("n=");
            n = int.Parse(Console.ReadLine());
            Console.Write("k=");
            k = int.Parse(Console.ReadLine());
            st[0] = 0;
            Bkt();
        }

        private static void Bkt()
        {
            int c = 1;
            st[c] = 0;
            while (c>0)
            {
                while(st[c]<n)
                {
                    st[c] = st[c] + 1;
                    if (Valid(c))
                    {
                        if (c==k)
                        {
                            Tipar(c);
                        }
                        else
                        {
                            c = c + 1;
                            st[c] = 0;
                        }
                    }                   
                }
                c = c - 1;
            }
        }

        private static void Tipar(int c)
        {
            for (int i = 1; i <= c; i++)
            {
                Console.Write("{0} ", st[i]);
            }
            Console.WriteLine();
        }

        private static bool Valid(int c)
        {
            
            if (st[c] > st[c - 1])
            {
                return true;
            }
            else
                return false;
        }
    }
}
