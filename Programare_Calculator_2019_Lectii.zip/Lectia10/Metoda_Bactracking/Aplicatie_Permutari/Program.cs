﻿using System;

namespace Aplicatie_Permutari
{
    class Program
    {
        static void Main(string[] args)
        {
            int n;
            string linie;
            string[] el;
            Console.WriteLine("Introdu elementele multimii pe o linie separate prin spatiu:");
            linie = Console.ReadLine();
            el = linie.Split(' ');
            //Formam multimea de numere intregi ma
            n = el.Length;
            int[] ma = new int[n];
            for (int i = 0; i < n; i++)
            {
                ma[i] = int.Parse(el[i]);
            }
            Console.WriteLine("\nMultimea intiala:");
            Afisare(ma);
            Bactracking(ma);
            Console.ReadKey();
        }

        private static void Bactracking(int[] ma)
        {
            int k = 0;
            //Alocam memorie pentru sirul de indici
            int[] x = new int[ma.Length];
            int nrSol = 0;
            //Initalizam multimea x
            for (int i = 0; i < x.Length; i++)
            {
                x[i] = 0;
            }
            //Procesul de bactracking
            while (k>=0)
            {
                if (k==x.Length)//Am gasit solutia
                {
                    ReturnSolutia(ma, x, ++nrSol);//Afisam solutia
                    k--;//revenire dupa ce o solutie afost gasita
                }
                else
                {
                    if (x[k]<x.Length)//Mai sunt valori neverificate?
                    {
                        //Se ia urmatoarea valoare neverificata
                        x[k]++;
                        //respecta valoarea aleasa
                        //conditia de continuare?
                        if (Continuare(x,k))
                        {
                            k++;//avanseaza
                        }
                    }
                    else
                    {
                        x[k--] = 0;//revenire;
                    }
                }
            }
        }

        private static bool Continuare(int[] x, int k)
        {
            for (int i = 0; i < k; i++)
            {
                if (x[k]==x[i])
                {
                    return false;
                }
            }
            return true;
        }

        private static void ReturnSolutia(int[] ma, int[] x, int nrSol)
        {
            Console.Write("Permutarea {0} : ", nrSol);
            for (int i = 0; i < ma.Length; i++)
            {
                Console.Write("{0} ", ma[x[i] - 1]);
            }
            Console.WriteLine("\n--------------------------------------------");
        }

        private static void Afisare(int[] ma)
        {
            foreach (int item in ma)
            {
                Console.Write("{0} ", item);
            }
            Console.WriteLine("\n");
        }
    }
}
