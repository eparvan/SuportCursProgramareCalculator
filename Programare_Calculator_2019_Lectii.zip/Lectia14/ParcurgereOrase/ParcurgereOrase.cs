﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParcurgereOrase
{
    /*Harta rutiera a unei tari este formata din n orase si m sosele intre 2 orase, 
     * fiecare sosea fiind caractezizata prin distanta in kilometri (numar natural). 
Trei prieteni se gasesc in 3 orase distincte x, y, z si isi propun sa se intalneasce intr-un oras t. 
Calculati si afisati distanta minima pe care o parcurge fiecare prieten din orasul de pornire pana in orasul t de destinatie. 
Afisati cele trei orase de plecare in ordinea in care cei trei prieteni ajung in orasul t. 
Exemplu: 
date.in 
12 19 (n,m) 
1 2 20 (oras 1, oras 2, distanta) 
1 3 35 
1 7 20 
2 4 30 
3 4 40 
3 6 40 
3 8 80 
4 5 25 
5 6 5 
6 8 30 
6 9 10 
7 8 15 
7 11 100 
8 9 40 
8 10 30 
8 11 35 
9 10 30 
10 12 25 
11 12 10 
1 5 3 12 (x, y, z, t) 
date.out 
Distantele parcurse de cei trei prieteni: 
80 70 105 
Orasele de plecare in ordinea in care ajung cei trei prieteni: 
5 1 3 
     */
    class ParcurgereOrase
    {
        static void Main(string[] args)
        {
        }
    }
}
