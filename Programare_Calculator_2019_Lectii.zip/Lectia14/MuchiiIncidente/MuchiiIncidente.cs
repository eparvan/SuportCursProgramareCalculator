﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace MuchiiIncidente
{
    /*Se da un graf neorientat cu n varfuri si m muchii. 
     * Afisati grupurile de muchii incidente. 
Exemplu 
n=5 , m=4 
muchiile: 
[1,2] 
[1,3] 
[1,4] 
[3,4] 

        
        
        grupurile de muchii incidente sunt 
[1,2] [1,3] [1,4] 
[1,3] [3,4] 
[1,4] [3,4] 
     */
    class MuchiiIncidente
    {
        static StreamReader fin = new StreamReader("date.in");
        static StreamWriter fout =new StreamWriter("date.out");
        static int[,] ma;
        static int n, m;
        static void Main(string[] args)
        {
            Citire();
            using (fout)
            {
                for (int i = 0; i <n; i++)
                {
                    if (Grad(i) >= 2)
                    {
                        for (int j = 0; j < n; j++)
                        {
                            if (ma[i, j] == 1)
                            {
                                fout.Write("[{0},{1}] ", i, j);
                            }
                        }
                        fout.WriteLine();
                    }
                }
            }
            Afisare();
            Console.ReadKey();           
        }

        private static void Afisare()
        {
            for (int i = 1; i <= n; i++)
            {
                for (int j = 1; j <= n; j++)
                {
                    Console.Write("{0} ", ma[i,j]);
                }
                Console.WriteLine();
            }
        }
        private static int Grad(int v)
        {
            int g = 0;
            for (int i = 0; i < n; i++)
            {
                g = g + ma[v, i];
            }
            return g;
        }

        private static void Citire()
        {
            using (fin)
            {
                string[] linie;
                linie = fin.ReadLine().Split(' ');
                n = int.Parse(linie[0]);
                m = int.Parse(linie[1]);
                ma = new int[n+1, n+1];
                for (int i = 0; i < m; i++)
                {
                    int x, y;
                    linie= fin.ReadLine().Split(' ');
                    x = int.Parse(linie[0]);
                    y = int.Parse(linie[1]);
                    ma[x, y] = ma[y, x] = 1;
                }
            }
        }
    }
}
