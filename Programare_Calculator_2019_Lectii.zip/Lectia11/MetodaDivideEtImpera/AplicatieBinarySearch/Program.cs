﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AplicatieBinarySearch
{
    /* Căutarea binară

        Se dă un vector sortat crescător (v[1..n]) ce conține valori reale distincte
        și o valoare x. 
        Sa se găsească la ce poziție apare x în vectorul dat.
        Pentru rezolvarea acestei probleme folosim un algoritm D&I:
        Divide: împărțim vectorul în doi sub-vectori de dimensiune n/2.
        Stăpânește: aplicăm algoritmul de căutare binară pe sub-vectorul care conține
        valoarea căutată.
        Combină: soluția sub-problemei devine soluția problemei inițiale, 
        motiv pentru care nu mai este nevoie de etapa de combinare.

    */
    class Program
    {
        //metoda iterativa
        static int BinarySearch(int[] masiv, int key)
        {

            int left, right, middle;
            left = 0;
            right = masiv.Length - 1;
            while (left <= right)
            {
                middle = (left + right) / 2;
                if (key < masiv[middle])
                    right = middle - 1;
                else
                    if (key > masiv[middle])
                    left = middle + 1;
                else
                    return middle;
            }
            return -1;
        }

        //Metoda recursiva

        static int BinarySearch(int[] masiv, int left, int right, int key)
        {
            if (left >= right)
            {
                int middle = left + (right - left) / 2;
                if (masiv[middle] == key) return middle;
                if (masiv[middle] > key)
                    return BinarySearch(masiv, left, middle - 1, key);
                return BinarySearch(masiv, middle + 1, right, key);
            }
            return -1;
        }
        public static void AfisareMasiv(int[] masiv)
        {
            Console.WriteLine("Masivul intial:");
            foreach (int item in masiv)
            {
                Console.Write("{0} ", item);
            }
        }
        static void Main(string[] args)
        {
            string go = "";
            do
            {
                Console.Clear();

                Console.Write("Numarul de elemente ale masivului: n= ");
                int n = int.Parse(Console.ReadLine());
                int[] masiv = new int[n];
                Random element = new Random();
                for (int i = 0; i < n; i++)
                {
                    masiv[i] = element.Next(1, 100);
                }

                Array.Sort(masiv);
                AfisareMasiv(masiv);
                Console.Write("\nValoarea cautata key=");
                int key = int.Parse(Console.ReadLine());
                int resultat = BinarySearch(masiv, key);
                if (resultat == -1)
                {
                    AfisareMasiv(masiv);
                    Console.WriteLine("\nElementul {0} lipseste!", key);
                }
                else
                {
                    AfisareMasiv(masiv);
                    Console.WriteLine("\nElementul {0} se afla pe pozitia {1}", key, resultat);
                }
                Console.Write("Pentru iesire scrieti: quit");
                go = Console.ReadLine();
            } while (go != "quit");
            Console.ReadKey();
        }
    }

}
