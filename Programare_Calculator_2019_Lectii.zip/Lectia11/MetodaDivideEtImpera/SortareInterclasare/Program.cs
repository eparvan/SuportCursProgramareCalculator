﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortareInterclasare
{
    /*
 * 
    Sortarea prin interclasare (MergeSort) este un algoritm de sortare de vectori 
    ce folosește paradigma D&I:
    Divide: împarte vectorul inițial în doi sub-vectori de dimensiune n/2.
    Stăpânește: sortează cei doi sub-vectori recursiv folosind sortarea prin interclasare; 
    recursivitatea se oprește când dimensiunea unui sub-vector este 1 (deja sortat).
    Combina: Interclasează cei doi sub-vectori sortați pentru a obține vectorul inițial sortat.

 */

    class Program
    {
        static void Main(string[] args)
        {
            List<int> unsorted = new List<int>();
            List<int> sorted;
            
            Random random = new Random();

            Console.WriteLine("Elementele masivului initial:");
            for (int i = 0; i < 10; i++)
            {
                unsorted.Add(random.Next(0, 100));
                Console.Write(unsorted[i] + " ");
            }
            Console.WriteLine();
            unsorted.Sort();
            sorted = MergeSort(unsorted);

            Console.WriteLine("Masivul sortat: ");
            foreach (int x in sorted)
            {
                Console.Write(x + " ");
            }
            Console.Write("\n");
            Console.ReadKey();

        }
        private static List<int> MergeSort(List<int> unsorted)
        {
            if (unsorted.Count <= 1)
                return unsorted;

            List<int> left = new List<int>();
            List<int> right = new List<int>();

            int middle = unsorted.Count / 2;
            for (int i = 0; i < middle; i++)  //Impartirea liste nesortate
            {
                left.Add(unsorted[i]);
            }
            for (int i = middle; i < unsorted.Count; i++)
            {
                right.Add(unsorted[i]);
            }

            left = MergeSort(left);
            right = MergeSort(right);
            return Merge(left, right);
        }
        private static List<int> Merge(List<int> left, List<int> right)
        {
            List<int> result = new List<int>();

            while (left.Count > 0 || right.Count > 0)
            {
                if (left.Count > 0 && right.Count > 0)
                {
                    if (left.First() <= right.First())  //Se compara primele doua elemente, care este mai mic
                    {
                        result.Add(left.First());
                        left.Remove(left.First());      //Rstul elementelor listei fara primul element
                    }
                    else
                    {
                        result.Add(right.First());
                        right.Remove(right.First());
                    }
                }
                else if (left.Count > 0)
                {
                    result.Add(left.First());
                    left.Remove(left.First());
                }
                else if (right.Count > 0)
                {
                    result.Add(right.First());

                    right.Remove(right.First());
                }
            }
            return result;
        }


    }
}
