﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SumaElementeMasiv
{
    /*
     De creat un tabel unidimensional de numere intregi 
     (generat aleatoriu).
     Să secalculeze suma elementelor prime din acest tabel.
         */
    class Program
    {
        static void Main(string[] args)
        {
            int[] tabel;
            int size;
            Console.Write("Dimensiunea tabelului: n= ");
            size = int.Parse(Console.ReadLine());
            tabel = CreareTabel(size);

            Console.WriteLine("Tabelul initial:");
            AfisareTabel(tabel);

            int sumaPrime = 0;
            Console.WriteLine();
            for (int i = 0; i < size; i++)
            {
                if (NumarPrim(tabel[i]))
                {
                    Console.Write("{0} + ", tabel[i]);
                    sumaPrime+=tabel[i];
                }
            }

            //Stergerea ultimelor semne de + si spatiu
            //if (sumaPrime!=0)
            //{
            //    Console.SetCursorPosition(Console.CursorLeft - 2, Console.CursorTop);
            //}
            
            Console.WriteLine(" = {0} ", sumaPrime);
            Console.ReadKey();
        }

        public static int[] CreareTabel(int size)
        {
            int[] tabel= new int[size];
            Random element = new Random();
            for (int i = 0; i < size; i++)
            {
                tabel[i] = element.Next(1, 100);
            }
            return tabel;
        }

        private static void AfisareTabel(int[] tabel)
        {
            for (int i = 0; i < tabel.Length; i++)
            {
                Console.Write("{0} ", tabel[i]);
            }
        }

        public static bool NumarPrim(int numar)
        {
            int nr = 0;
            for (int d = 2; d < numar/2; d++)
            {
                if (numar%d==0)
                {
                    nr++;
                }
            }
            if (nr == 0)
            {
                return true;
            }
            else return false;
        }
    }
}
