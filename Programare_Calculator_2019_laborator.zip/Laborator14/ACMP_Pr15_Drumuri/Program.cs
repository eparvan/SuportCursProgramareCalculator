﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace ACMP_Pr15_Drumuri
{
    /*Într-o împărăție erau N orașe, între careva din ele existau drumuiri.
     * Împăratul a hotărît să afle între care orașe există drumuri și a dat 
     * poruncă să se calculeze cîte drumuri există în această împărăție.
     * Elaborați un program ce va calula cîte drumuri sunt în această
     * împărăție.
     * Date de intrare: Fișierul INPUT.TXT conține pe prima linie un număr N (0 ≤ N ≤ 100).
     * Pe următoarele N linii se află N cifre de 0 sau 1. Dacă în poziția (i, j) se află 0 atunci
     * între orașele (i, j) nu este drum, dacă este 1, atunci  drum există.
     * 
     * Date de ieșire: În fișierul OUTPUT.TXT se va conține un număr - numărul de drumuri în împărăție.
     * 
     * Exemplu:
     * INPUT.TXT
     *  5
        0 1 0 0 0
        1 0 1 1 0
        0 1 0 0 0
        0 1 0 0 0
        0 0 0 0 0

        OUTPUT.TXT
        3

        Explicație: Drumuri intre orașele- (1,2), (2,3), (2,4)
     */
    class Program
    {
        static StreamReader fin = new StreamReader("INPUT.TXT");
        static StreamWriter fout = new StreamWriter("OUTPUT.TXT");
        static int n;
        static int[,] map;
        static int ndr=0;
        static void Main(string[] args)
        {
            string linie;
            string[] elemlinie;
            try
            {
                using (fin)
                {
                    linie = fin.ReadLine();
                    n = int.Parse(linie);
                    map = new int[n + 1, n + 1];
                    for (int i = 1; i <= n; i++)
                    {
                        linie = fin.ReadLine();
                        elemlinie = linie.Split(' ');

                        for (int j = 1; j <= n; j++)
                        {
                            map[i, j] = int.Parse(elemlinie[j - 1]);
                        }
                    }
                }
               
            }
            catch (Exception)
            {

                Console.WriteLine("Eroare! la deschiderea fisierului!");
            }
            try
            {
                using (fout)
                {
                    for (int i = 1; i <= n; i++)
                    {
                        for (int j = i; j <= n; j++)
                        {
                            if (map[i,j]==1)
                            {
                                ndr++;
                            }
                        }
                    }
                    fout.Write(ndr);
                }
            }
            catch (Exception)
            {

                Console.WriteLine("Eroare! la scrierea fisierului!");
            }
        }
    }
}
