﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace ACMP_Pr_10
{
    class Program
    {

        static StreamReader fin = new StreamReader("INPUT.TXT");
        static StreamWriter fout = new StreamWriter("OUTPUT.TXT");
        static long a, b,c,d;
        static void Main(string[] args)
        {
            Citeste();
            Scrie();
        }

        private static void Scrie()
        {
            using (fout)
            {
                for (int i = -100; i <= 100; i++)
                {
                    if ((a*i*i*i+b*i*i +c*i +d)==0 )
                    {
                        fout.Write("{0} ", i);
                    }
                }
            }
        }

        private static void Citeste()
        {
            using (fin)
            {
                string[] linie = fin.ReadLine().Split(' ');
                a = int.Parse(linie[0]);
                b = int.Parse(linie[1]);
                c = int.Parse(linie[2]);
                d = int.Parse(linie[3]);

            }
        }
    }
}
