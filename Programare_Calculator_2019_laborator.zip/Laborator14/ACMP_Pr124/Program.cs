﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace ACMP_Pr124
{
    /*. Într-o subterană sunt M tunelrui și N intersecții, fiecare tunel unește careva două intersecții. S-a hotărît să fie instalate semafoare înaintea fiecărei intersecții. Elaborați o aplicație, care va calcula, cîte semafoare trebuie de instalat înaintea fiecărei intersecții. Intersecțiile sunt numerotate de la 1 la N.
Date de intrare: Fișierul INPUT.TXT pe prima linie se conțin numerele N și M (0 < N ≤ 100, 0 ≤ M ≤ N*(N-1)/2). Pe următoare M linii sunt scrie câte două numere i și j (1 ≤ i,j ≤ N), care reprezintă că intersecția i și j este unită cu un tunel. Nu există tunel doar de la intersecția i pînă la sine însăși.
Fișierul de ișire OUTPUT.TXT va conține N numere: fiecare k număr va reprezenta cantitatea de semafoare la intersecția k.
Exemplu:
INPUT.TXT
7 10
5 1
3 2
7 1
5 2
7 4
6 5
6 4
7 5
2 1
5 3
OUTPUT.TXT
3 3 2 2 5 2 3

     */
    class Program
    {
        static StreamReader fin = new StreamReader("INPUT.TXT");
        static StreamWriter fout = new StreamWriter("OUTPUT.TXT");
        static int n, m;
        static int[,] map;
        static int nrsem = 0;
        static void Main(string[] args)
        {
            Citeste();
            Scrie();
           
        }

        private static void Scrie()
        {
            using (fout)
            {
                for (int i = 1; i <= n; i++)
                {
                    nrsem = 0;
                    for (int j = 1; j <= n; j++)
                    {
                        if (map[i, j] == 1)
                        {
                            nrsem++;
                        }
                    }
                    fout.Write("{0} ", nrsem);
                }
            }
            
        }

        private static void Citeste()
        {
            using (fin)
            {
                string[] linie;
                linie = fin.ReadLine().Split(' ');
                n = int.Parse(linie[0]);
                m = int.Parse(linie[1]);
                map = new int[n + 1, n + 1];
                for (int i = 1; i <= m; i++)
                {
                    int x, y;
                    linie = fin.ReadLine().Split(' ');
                    x = int.Parse(linie[0]);
                    y = int.Parse(linie[1]);
                    map[x, y] = map[y, x] = 1;
                }
            }
        }
    }
}
