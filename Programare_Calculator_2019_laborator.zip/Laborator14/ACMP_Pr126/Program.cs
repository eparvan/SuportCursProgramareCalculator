﻿using System;

using System.IO;

namespace ACMP_Pr126
{
    /*Problema Nr.126 ACMP.RU
     */
    class Program
    {
        static StreamReader fin = new StreamReader("INPUT.TXT");
        static StreamWriter fout = new StreamWriter("OUTPUT.TXT");
        static int n;
        static int[,] map;
        static int min=int.MaxValue;
        
        static void Main(string[] args)
        {
            Citeste();
            Scrie();
        }
        private static void Citeste()
        {
            string linie;
            string[] elemlinie;
            try
            {
                using (fin)
                {
                    linie = fin.ReadLine();
                    n = int.Parse(linie);
                    map = new int[n + 1, n + 1];
                    
                    for (int i = 1; i <= n; i++)
                    {
                        linie = fin.ReadLine();
                        elemlinie = linie.Split(' ');

                        for (int j = 1; j <= n; j++)
                        {
                            map[i, j] = int.Parse(elemlinie[j - 1]);
                        }
                    }                  

                }

            }
            catch (Exception)
            {

                Console.WriteLine("Eroare! la deschiderea fisierului!");
            }
        }
        private static void Scrie()
        {
            try
            {
                using (fout)
                {
                    int sum = 0;
                    for (int i = 1; i <= n; i++)
                    {
                        if (i==1)
                        {
                            min = map[1, 2];
                        } else min = map[i, 1];
                        for (int j = 1; j <= n; j++)
                        {
                            if (min>map[i,j] && map[i,j]!=0)
                            {
                                min = map[i, j];
                            }                           
                        }                        
                        sum += min;
                    }
                    fout.Write(sum);
                }
            }
            catch (Exception)
            {

                Console.WriteLine("Eroare! la scrierea fisierului!");
            }
        }
    }
}
