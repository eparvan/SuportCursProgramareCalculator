﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace ACMP_Pr1201
{
    /*Ориентированный невзвешенный граф без петель и кратных ребер задан своей матрицей смежности.

По данному представлению следует вывести представление графа в виде списка ребер.

Входные данные
Первая строка входного файла INPUT.TXT содержит натуральное число N (N ≤ 100) – число вершин графа. Далее следуют N строк по N цифр, каждая из которых равна 0 или 1, задающих матрицу смежности.

Выходные данные
В выходной файл OUTPUT.TXT в первой строке выведите два целых числа N и M – количество вершин и ребер в графе соответственно. В последующих M строках в произвольном порядке выведите описание ребер.

Примеры
№	INPUT.TXT	
1	4
0 1 0 0
0 0 0 0
1 1 0 1
0 1 1 0	

OUTPUT.TXT
4 6
1 2
3 1
3 2
3 4
4 2
4 3

     */
    class Program
    {
        static StreamReader fin = new StreamReader("INPUT.TXT");
        static StreamWriter fout = new StreamWriter("OUTPUT.TXT");
        static int n, m;
        static int[,] map;
        static int nrmuchii = 0;
        static void Main(string[] args)
        {
            Citeste();
            Scrie();
        }

        private static void Scrie()
        {
            using (fout)
            {
                fout.WriteLine("{0} {1}",n, nrmuchii);
                for (int i = 1; i <= n; i++)
                {
                   
                    for (int j = 1; j <= n; j++)
                    {
                        if (map[i, j] == 1)
                        {
                            fout.WriteLine("{0} {1}", i, j);
                        }
                    }
                    
                }
            }

        }

        private static void Citeste()
        {
            string linie;
            string[] elemlinie;
            try
            {
                using (fin)
                {
                    linie = fin.ReadLine();
                    n = int.Parse(linie);
                    map = new int[n + 1, n + 1];
                   
                    for (int i = 1; i <= n; i++)
                    {
                        linie = fin.ReadLine();
                        elemlinie = linie.Split(' ');

                        for (int j = 1; j <= n; j++)
                        {
                            map[i, j] = int.Parse(elemlinie[j - 1]);
                            if (map[i,j]==1)
                            {
                                nrmuchii++;
                            }
                        }
                    }
                    

                }

            }
            catch (Exception)
            {

                Console.WriteLine("Eroare! la deschiderea fisierului!");
            }
        }
    }
}
