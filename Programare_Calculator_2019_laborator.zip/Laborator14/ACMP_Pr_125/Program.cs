﻿using System;
using System.IO;

namespace ACMP_Pr_125
{

   
    class Program
    {
        static StreamReader fin = new StreamReader("INPUT.TXT");
        static StreamWriter fout = new StreamWriter("OUTPUT.TXT");
        static int n;
        static int[,] map;
        static int [] culori;
        static int nrpod=0;
        static void Main(string[] args)
        {
            Citeste();
            Scrie();
           
        }

        private static void Scrie()
        {
            try
            {
                using (fout)
                {
                    
                    for (int i = 1; i <= n; i++)
                    {
                        for (int j =i; j <= n; j++)
                        {
                            if (map[i, j] ==1 && culori[i-1]!=culori[j-1])
                            {
                                nrpod++;
                              
                            }
                        }
                    }
                    fout.Write(nrpod);
                }
            }
            catch (Exception)
            {

                Console.WriteLine("Eroare! la scrierea fisierului!");
            }
        }

        private static void Citeste()
        {
            string linie;
            string[] elemlinie;
            try
            {
                using (fin)
                {
                    linie = fin.ReadLine();
                    n = int.Parse(linie);
                    map = new int[n + 1, n + 1];
                    culori = new int[n + 1];
                    for (int i = 1; i <= n; i++)
                    {
                        linie = fin.ReadLine();
                        elemlinie = linie.Split(' ');

                        for (int j = 1; j <= n; j++)
                        {
                            map[i, j] = int.Parse(elemlinie[j - 1]);
                        }
                    }
                    fin.ReadLine();
                    linie = fin.ReadLine();
                    elemlinie = linie.Split(' ');
                    for (int i = 0; i < n; i++)
                    {
                        culori[i] = int.Parse(elemlinie[i]);
                    }

                }

            }
            catch (Exception)
            {

                Console.WriteLine("Eroare! la deschiderea fisierului!");
            }
        }
    }
}
