﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace AplicatieInterschimbare
{
    /*Subgrupa 2: Dintr-un fișier text se citesc un șir de numere întregi. 
     * Ele se vor stoca într-o listă unidirecțională.
     * De interschimbat prin metoda trierii elementul maxim cu cel minim 
     * și de afișat la ecran rezultuatul interschimbarii și elementele minim și maxim.
     */
    class Program
    {
        public static List<int> date = new List<int>();
        public static string InputFileName = "date.in";
        static void Main(string[] args)
        {
            using (StreamReader fin = new StreamReader(InputFileName))
            {
                string continut;
                char[] separator = { ' ' };
                string[] numere;
                continut = fin.ReadToEnd();
                numere = continut.Split(separator, StringSplitOptions.RemoveEmptyEntries);
                for (int i = 0; i < numere.Length; i++)
                {
                    int numar = int.Parse(numere[i]);
                    date.Add(numar);
                }
            }
            int elementMinim = 0;
            int elementMaxim = 0;

            Console.WriteLine("Lista initiala:");
            AfisareLista(date, elementMinim, elementMaxim);
            Console.WriteLine();
            InterschimbareMinMax(date, ref elementMinim, ref elementMaxim);
            Console.WriteLine("Lista modificata:");
            AfisareLista(date, elementMinim, elementMaxim);
            Console.ReadKey();
        }

        private static void InterschimbareMinMax(List<int> date, ref int elementMinim, ref int elementMaxim)
        {
            int min = 0;
            int max = 0;

            for (int i = 1; i < date.Count; i++)
            {
                if (date[min] < date[i])
                    min = i;
                if (date[max] > date[i])
                    max = i;
            }
            int temp = date[min];
            date[min] = date[max];
            date[max] = temp;
            elementMinim = date[min];
            elementMaxim = date[max];
        }

        private static void AfisareLista(List<int> date, int elementMinim, int elementMaxim)
        {
            for (int i = 0; i < date.Count; i++)
            {
                Console.Write("{0} ", date[i]);
            }
            Console.WriteLine();
            Console.WriteLine("Elementul minim: {0}\nElementul maxim: {1}", elementMinim, elementMaxim);
        }
    }
}
