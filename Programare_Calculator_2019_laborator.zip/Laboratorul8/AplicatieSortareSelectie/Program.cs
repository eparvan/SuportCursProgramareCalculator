﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace AplicatieSortareSelectie
{
    /*Laboratorul 8
Dintr-un fișier text se citesc un șir de numere întregi. 
Ele se vor stoca într-o listă unidirecțională. 
De sortat elementele listei prin metoda selecției și de afișat la ecran 
rezultuatul sortării și numărul de operații efectuate la sortare.

     */
    class Program
    {
        public static List<int> date = new List<int>();
        public static string InputFileName = "date.in";
        static void Main(string[] args)
        {
            using (StreamReader fin= new StreamReader(InputFileName))
            {
                string continut;
                char[] separator = { ' ' };
                string[] numere;
                continut= fin.ReadToEnd();
                numere = continut.Split(separator, StringSplitOptions.RemoveEmptyEntries);
                for (int i = 0; i < numere.Length; i++)
                {
                    int numar = int.Parse(numere[i]);
                    date.Add(numar);
                }
            }
            int numarOperatii=0;

            Console.WriteLine("Lista initiala:");
            AfisareLista(date, numarOperatii);
            Console.WriteLine();

            SortareSelectie(date, ref numarOperatii);
            
            Console.WriteLine("Lista sortata:");
            AfisareLista(date, numarOperatii);
            Console.ReadKey();
        }

        private static void AfisareLista(List<int> date, int numarOperatii)
        {
            for (int i = 0; i < date.Count; i++)
            {
                Console.Write("{0} ", date[i]);
            }
            Console.WriteLine();
            Console.WriteLine("Numarul de operatii: {0}", numarOperatii);
        }

        private static void SortareSelectie(List<int> date, ref int n)
        {
            n = 0;
            for (int i = 0; i < date.Count; i++)
            {
                int min = i;
                n++;
                for (int j = i+1; j < date.Count; j++)
                {
                    n++;
                    if (date[j]<date[min])
                    {
                        min = j;
                        n++;
                    }
                }
                int aux = date[min];n++;
                date[min] = date[i]; n++;
                date[i] = aux; n++;

            }
        }
    }
}
