﻿using System;


namespace Aplicatie01
{
    /*Calea de cost minim
     * Este data o matrice (m,n). Să se calculeze calea de cost minim pentrui a ajunge din 
     * celula (0,0) în celula (m, n)
     * Faceti referire la imaginea din proiect.
     
         */
    class Program
    {
        static void Main(string[] args)
        {
            int [,] cost= { {1, 2, 3},
                             {4, 8, 2},
                             {1, 5, 3}};
            Console.Write(MinCost(cost, 2,2));
            Console.ReadKey();
        }

        //Implementare> tehnica programarii dinamice
        private static int MinCost(int[,] cost, int m, int n)
        {
            int i, j;
            int[,] tc = new int[m + 1, n + 1];
            tc[0, 0] = cost[0, 0];
            //initializarea primei coloanei cu costul total din masiv cost(tc)
            for (i = 1; i <= m; i++)
                tc[i, 0] = tc[i - 1, 0] + cost[i, 0];

            /* Initializare primului rind din masivul tc  */
            for (j = 1; j <= n; j++)
                tc[0, j] = tc[0, j - 1] + cost[0, j];

            /* Construirea restului din masivul tc*/
            for (i = 1; i <= m; i++)
                for (j = 1; j <= n; j++)
                    tc[i, j] = Min(tc[i - 1, j - 1],
                                tc[i - 1, j],
                                tc[i, j - 1]) + cost[i, j];

            return tc[m, n];
        }

        //Metoda recursiva
        static int MinCostRecursiv(int[,] cost,
                       int m, int n)
        {
            if (n < 0 || m < 0)
                return int.MaxValue;
            else if (m == 0 && n == 0)
                return cost[m, n];
            else
                return cost[m, n] +
                       Min(MinCostRecursiv(cost, m - 1, n - 1),
                       MinCostRecursiv(cost, m - 1, n),
                       MinCostRecursiv(cost, m, n - 1));
        }
        //Metoda Min
        private static int Min(int x, int y, int z)
        {
            if (x < y)
                return (x < z) ? x : z;
            else
                return (y < z) ? y : z;
        }
    }
}
