﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AplicatieFibonacci
{
    /*Determinarea elementului din sirul Fibonacci prin programare dinamica
     */
    class Program
    {
        static int[] saveFib = new int[100];
        static void Main(string[] args)
        {
            int p;
            Console.Write("p=");
            p = int.Parse(Console.ReadLine());
            Console.WriteLine("Termenul {0} din sirul Fibonacci calculat prin programare dinamica," +
                "abordare bottom-up (de jos in sus): {1}", p, FibonacciDpBu(p));
            Console.WriteLine("Termenul {0} din sirul Fibonacci calculat prin programare dinamica," +
               "abordare top-down (de sus in jos): {1}", p, FibonacciDpTd(p));
            Console.WriteLine("Termenul {0} din sirul Fibonacci calculat recursiv: {1}", p, FibonacciRecursiv(p));
            Console.WriteLine("Termenul {0} din sirul Fibonacci calculat iterativ: {1}", p, FibonacciIterativ(p));
            Console.ReadKey();
        }

        private static int FibonacciIterativ(int p)
        {
            int precedent = 1;
            int curent = 1;
            int urmator = 1;
            for (int i = 3; i <= p; i++)
            {
                urmator = curent + precedent;
                precedent = curent;
                curent = urmator;
            }
            return urmator;
        }

        private static int FibonacciRecursiv(int p)
        {
            if (p <= 2)
            {
                return 1;
            }
            else
            {
                return FibonacciRecursiv(p-1)+FibonacciRecursiv(p-2);
            }
        }

        private static int FibonacciDpBu(int p)
        {
            int[] fib = new int[p+1];
            fib[1] = 1;
            fib[2] = 1;
            for (int i = 3; i <= p; i++)
            {
                fib[i] = fib[i - 1] + fib[i - 2];
            }
            return fib[p];
            
        }

        private static int FibonacciDpTd(int p)
        {
            if (saveFib[p]>0)
            {
                return saveFib[p];
            }
            if (p<=1)
            {
                return p;
            }
            saveFib[p] = FibonacciDpTd(p - 1) + FibonacciDpTd(p - 2);
            return saveFib[p];
        }
    }
}
