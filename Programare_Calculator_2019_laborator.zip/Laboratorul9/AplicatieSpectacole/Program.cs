﻿using System;
using System.Collections.Generic;

namespace AplicatieSpectacole
{
    /*Problema spectacolelor.
     Să presupunem că dispunem de o mulţime S = 1,2,. ..,n de n activităţi (spec
tacole) care doresc să folosească o aceeaşi resursă (sala de spectacole). Această
resursă poate fi folosită de o singură activitate la un moment dat. Fiecare activi
tate i are un timp de start si şi un timp de terminare ti, unde Si <= ti,. Dacă este
selectată activitatea i, ea se desfăşoară pe durata intervalului [Si,ti). 
Două activităţi sunt compatibile dacă duratele lor de desfăşurare sunt disjuncte.
Problema spectacolelor (selectării activităţilor) constă în selectarea unei mulţimi
maximale de activităţi compatibile între ele.

     */
    class Program
    {
        public struct Spectacol
        {
            public int oraInceput;
            public int oraSfirsit;
        }
        static void Main(string[] args)
        {
            //Citirea datelor initiale:
            Console.Write("Introdu numarul de spectacole:");
            int n = int.Parse(Console.ReadLine());
            //Citirea timpilor de incepere si terminare a spectacolelor
            Console.Write("Introdu timpul de inceput si terminare a spectacolului:");
            List<Spectacol> lspect = new List<Spectacol>();
            Spectacol sp;
            for (int i = 1; i <= n; i++)
            {
                Console.Write("Inceput[{0}]=", i);
                sp.oraInceput = int.Parse(Console.ReadLine());
                Console.Write("Sfirsit[{0}]=", i);
                sp.oraSfirsit = int.Parse(Console.ReadLine());
                lspect.Add(sp);
            }
            //Ordonarea crescatoare a spectacolelor in functie de 
            //timpul de terminare a lor
            Ordonare(lspect);
            //Determinarea solutiei prin metoda Greedy
            List<Spectacol> sol = SelectSpectacole(lspect);
            //Afisarea rezultatelor
            Console.WriteLine("Organizarea spectacolelor:");
            foreach (var item in sol)
            {
                Console.WriteLine("ora inceput: {0} - ora sfirsit: {1}", item.oraInceput, item.oraSfirsit);
            }
            Console.ReadKey();
        }

        //Algoritmul de rezolvare prin metoda Greedy
        private static List<Spectacol> SelectSpectacole(List<Spectacol> lspect)
        {
            List<Spectacol> sol = new List<Spectacol>();
            //Daca spectacole nu sunt returnam valoarea 0
            if (lspect.Count == 0)
            {
                return sol;
            }
            //Adaugam in lista primul spectacol
            sol.Add(lspect[0]);
            //Dupa care sunt adaugate in lista solutiei acele spectacole  
            //in dependenta de ora de inceput si ora de sfirsit
            int j = 0;
            for (int i = 1; i < lspect.Count; i++)
            {
                if (lspect[i].oraInceput >= lspect[j].oraSfirsit)
                {
                    sol.Add(lspect[i]);
                    j = i;
                }
            }
            return sol;

        }


        private static void Ordonare(List<Spectacol> lspect)
        {
            // putem folosi si aceasta modalitate - lspect.Sort();
            //Dar vom sorta prin metoda bulelor
            int k;
            Spectacol aux;
            do
            {
                k = 0;
                for (int i = 0; i < lspect.Count - 1; i++)
                {
                    if (lspect[i].oraSfirsit > lspect[i + 1].oraSfirsit)
                    {
                        aux = lspect[i];
                        lspect[i] = lspect[i + 1];
                        lspect[i + 1] = aux;
                        k = 1;
                    }
                }
            } while (k == 1);
        }
    }
}
