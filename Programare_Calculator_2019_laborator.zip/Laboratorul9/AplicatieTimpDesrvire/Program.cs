﻿using System;
using System.Collections.Generic;

namespace AplicatieTimpDesrvire
{
    /*Programul pentru minimizarea timpului de asteptare 
     * al unui client pentru a fi deservit la o statie
     * (Metoda Greedy)
     */
    class Program
    {
        static void Main(string[] args)
        {
            //Citirea timpului de asteptare a fiecarui client
            int nClienti;
            Console.Write("Numarul de clienti:");
            nClienti = int.Parse(Console.ReadLine());
            Console.WriteLine("Introdu timpul de asteptare pentru fiecare client:");
            List<int> timpClient = new List<int>();
            for (int i = 0; i < nClienti; i++)
            {
                Console.Write("Timpul asteptare client {0} : ", i);
                int timpAsteptare = int.Parse(Console.ReadLine());
                timpClient.Add(timpAsteptare);
            }
            Ordonare(timpClient);
            Console.WriteLine("Timpul total de asteptare are valoare minima: {0}", CalculTimpMinim(timpClient));
            Console.ReadKey();
        }

        private static int CalculTimpMinim(List<int> timpClient)
        {
            int s = 0;
            Console.WriteLine("Ordinea de desrvire este:");
            for (int i = 1; i <= timpClient.Count; i++)
            {
                s += (timpClient.Count-i+1)*timpClient[i-1];
                Console.Write(" {0} ", timpClient[i-1]);
            }
            Console.WriteLine();
            return s;
        }

        private static void Ordonare(List<int> timpClient)
        {
            //Ordonare prin metoda bulelor
            int k, aux;
            do
            {
                k = 0;
                for (int i = 0; i < timpClient.Count-1; i++)
                {
                    if (timpClient[i] > timpClient[i+1])
                    {
                        aux = timpClient[i];
                        timpClient[i] = timpClient[i + 1];
                        timpClient[i + 1] = aux;
                        k = 1;
                    }
                }
            } while (k==1);
        }
    }
}
