﻿using System;
using System.IO;


namespace AplicatiePlataSumei
{/*Sa se efectueaze plata unei sume S utilizand un numar minim de bancnote.
     */
    class Program
    {
        //Metoda ce va afisa meniul aplicatiei
        public static int ShowMenu()
        {
           
            int userChoose_int = 0;
            bool ok;
            do
            {
                
                Console.WriteLine("1. Citeste datele: ");
                Console.WriteLine("2. Prelucreaza datele: ");
                Console.WriteLine("3. Afiseaza rezultatul din fisier: ");
                Console.WriteLine("0. Iesire");
                string userChoose = Console.ReadLine();
                ok = int.TryParse(userChoose, out userChoose_int);
                if (!ok)
                {
                    Console.WriteLine("Nu exista astfel de optiune!");
                }
            } while (!ok);
            return userChoose_int;
        }
        static void Main(string[] args)
        {
           
            ////Suma de bani
            int suma=0;

            //Nominalul bancnotelor
            int[] nominalb = new int[] { 1, 5, 10, 20, 50, 100, 200, 500, 1000 };
            //Console.Write("Suma=");
            //suma = int.Parse(Console.ReadLine());
            bool go = true;
            do
            {
                int userChoose = ShowMenu();
                switch (userChoose)
                {
                    case 1:
                        using (StreamReader fin = new StreamReader("Suma.in"))
                        {
                            suma = int.Parse(fin.ReadLine());
                        }
                        Console.Clear();
                        break;
                    case 2:
                        //Algoritmul de rezolvare prin metoda Greedy
                        MetodaGreedy(suma, nominalb);
                        Console.Clear();
                        break;
                    case 3:
                        Console.Clear();
                        using (StreamReader fout = new StreamReader("Suma.out"))
                        {
                            string rez;
                            rez=fout.ReadToEnd();
                            Console.WriteLine(rez);
                        }
                        break;
                    case 0:
                        go = false;
                        Console.WriteLine("Iesire");
                        break;
                    default:
                        Console.WriteLine("nu exista astfel de optiune!");
                        break;
                }
            } while (go);

            
            Console.ReadKey();
        }

        private static void MetodaGreedy(int suma, int[] nominalb)
        {
            int t = 0;
            int i = nominalb.Length - 1;
            using (StreamWriter fout = new StreamWriter("Suma.out"))
            {


                //Masivul cu nominalul de bancnote trebuie sa fie sortat
                //In cazul dat incepem de la cea mai mare spre cea mai mica valoare a bancnotei
                while (suma > 0)
                {
                    if (suma >= nominalb[i])
                    {

                        fout.WriteLine("{0} bancnote de valoarea {1} MDL",
                        suma / nominalb[i], nominalb[i]);
                    }
                    t += suma / nominalb[i]; //numarul de bancnote folosite
                    suma %= nominalb[i];    //cat mai ramine de platit
                    i--; //bancnota urmatoare ca valoare (mai mica)
                }
                fout.WriteLine("Numarul de bancnote folosite: {0}", t);
            }
        }
    }
}
