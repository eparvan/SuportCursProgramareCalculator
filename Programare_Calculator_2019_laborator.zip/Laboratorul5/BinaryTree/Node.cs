﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BinaryTree
{
    class Node
    {
        public int Value { get; set;}  //valoarea nodului
        public Node RightNode { get; set; } //nodul sting

        public Node LeftNode { get; set; } //nodul drept

        public Node(int value) //constructorul nodului
        {
            this.Value = value;
        }
        public void PrintPretty(string indent, bool last)
        {

            Console.Write(indent);
            if (last)
            {
                Console.Write("└─");
                indent += "  ";
            }
            else
            {
                Console.Write("├─");
                indent += "| ";
            }
            Console.WriteLine(Value);

            var children = new List<Node>();
            if (this.LeftNode != null)
                children.Add(this.LeftNode);
            if (this.RightNode != null)
                children.Add(this.RightNode);

            for (int i = 0; i < children.Count; i++)
                children[i].PrintPretty(indent, i == children.Count - 1);

        }
    }
}
