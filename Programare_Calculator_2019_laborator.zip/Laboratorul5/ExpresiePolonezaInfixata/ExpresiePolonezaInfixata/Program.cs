﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExpresiePolonezaInfixata
{
    /*
     Se da o expresie aritmetica in forma poloneza prefixata. 
     Expresia este formata din operatorii + - / * %, 
     iar operanzii sunt dintr-un singur caracter.
     Construiti arborele binat asociat expresiei citite 
     si afisati expresia in forma normala (infixata).
    Exemplu:
            /-+*5314+27
            in forma normala este (((5*3)+1)-4)/(2+7)
         */
    class Program
    {
        static bool[] S = new bool[100];
        static int[] D = new int[100];
        static int[] T = new int[100];
        static void Main(string[] args)
        {
            string expresia;
            using (StreamReader fin = new StreamReader("date.in"))
            {
                expresia = fin.ReadLine();
            }

            int n = expresia.Length - 1;
            T[0] = -1;
            bool pus, v;
            for (int i = 0; i <= expresia.Length; i++)
            {
                pus = false; v = false;
                while (!pus)
                {
                    while (S[v] )
                    {

                    }
                }
            }

            Console.WriteLine("Expresia: {0}", expresia);
            Console.ReadLine();
        }
    }
}
