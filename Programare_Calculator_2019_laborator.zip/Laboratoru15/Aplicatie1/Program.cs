﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Aplicatie1
{
    class Program
    {
        static StreamReader fin = new StreamReader("date.in");
        static StreamWriter fout = new StreamWriter("date.out");
        static int inf = 100000;
        static int n, m;
        static int[,] ma;
        static int dmin = 100;
        static int[] s = new int[101];
        static void Main(string[] args)
        {
            using (fin)
            {
                string[] linie= fin.ReadLine().Split(' ');
                n = int.Parse(linie[0]);
                m = int.Parse(linie[1]);
                ma = new int[n+1,n+1];
                for (int i = 1; i <= n; i++)
                {
                    for (int j = 1; j <= n; j++)
                    {
                        if (i!=j)
                        {
                            ma[i, j] = inf;
                        }
                    }
                }
                for (int i = 1; i <= m; i++)
                {
                    int x, y;
                    linie = fin.ReadLine().Split(' ');
                    x = int.Parse(linie[0]);
                    y = int.Parse(linie[1]);
                    ma[x, y] = 1;
                }
                //Console.WriteLine("Matricea de adiacenta:");
                //for (int i = 1; i <= n; i++)
                //{
                //    for (int j = 1; j <= n; j++)
                //    {
                //        Console.Write("{0,12}  ", ma[i,j]);
                //    }
                //    Console.WriteLine();
                //}
                //Console.ReadKey();
                RF();
                //Console.WriteLine("Matricea de adiacenta modificata:");
                //for (int i = 1; i <= n; i++)
                //{
                //    for (int j = 1; j <= n; j++)
                //    {
                //        Console.Write("{0,12}  ", ma[i, j]);
                //    }
                //    Console.WriteLine();
                //}
                Console.ReadKey();
                for (int i = 1; i <= n; i++)
                {
                    int suma = 0;
                    for (int j = 1; j <= n; j++)
                    {
                        suma = suma + ma[i, j];
                    }
                    s[i] = suma;
                    if (s[i]<dmin)
                    {
                        dmin = s[i];
                    }
                }
                using (fout)
                {
                    for (int i = 1; i <= n; i++)
                    {
                        if (s[i]==dmin)
                        {
                            fout.Write("{0} ", i);
                        }
                    }
                }
            }
           
        }

        private static void RF()
        {
            for (int k = 1; k <= n; k++)
            {
                for (int i = 1; i <= n; i++)
                {
                    for (int j = 1; j <= n; j++)
                    {
                        if (ma[i,j]>ma[i,k]+ma[k,j])
                        {
                            ma[i, j] = ma[i, k] + ma[k, j];
                        }
                    }
                }
            }
        }
    }
}
