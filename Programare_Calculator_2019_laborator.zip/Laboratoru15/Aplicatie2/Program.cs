﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aplicatie2
{
    /*Să se completeze o stivă cu informația despre zece cărți: Denumirea și anul ediției. 
     * Să se sorteze aceste cărți în ordine descrescătoare după denumire și să se afișeze la ecran.
     */
    class Program
    {
        public struct Carti
        {
           public string denumire;
           public int aneditie;
        }
        static void Main(string[] args)
        {
            Stack<Carti> stivaCarti = new Stack<Carti>();
            //int n = 10;
            //Console.WriteLine("Introdu cartile:");
            Carti carte;
            //for (int i = 0; i < n; i++)
            //{
            //    Console.Write("Denumirea: ");
            //    carte.denumire = Console.ReadLine();
            //    Console.Write("Anul editie: ");
            //    carte.aneditie = int.Parse(Console.ReadLine());
            //    listaCarti.Push(carte);
            //}
            stivaCarti.Push(new Carti() { denumire="Informatica", aneditie=2000});
            stivaCarti.Push(new Carti() { denumire = "Fizica", aneditie = 2005 });
            stivaCarti.Push(new Carti() { denumire = "Matematica", aneditie = 2010 });
            stivaCarti.Push(new Carti() { denumire = "Geografia", aneditie = 2011 });
            stivaCarti.Push(new Carti() { denumire = "Astronomia", aneditie = 1999 });
            stivaCarti.Push(new Carti() { denumire = "Istoria", aneditie = 2009 });
            int n = stivaCarti.Count;
            Console.WriteLine("Stiva cartilor:");
            foreach (Carti item in stivaCarti)
            {
                Console.WriteLine("{0,20} - {1} ", item.denumire, item.aneditie);
            }

            //Algoritmul de sortare
           
            List<Carti> lCarti = new List<Carti>();
            for (int i = 0; i < n; i++)
            {
                lCarti.Add(stivaCarti.Pop());
            }
            //lCarti.Sort((x,y)=>x.denumire.CompareTo(y.denumire));
            
            Sortare(lCarti);
            for (int i = 0; i < n; i++)
            {
                carte.denumire = lCarti[i].denumire;
                carte.aneditie = lCarti[i].aneditie;
                stivaCarti.Push(carte);
            }
            Console.WriteLine("Stiva sortata a cartilor:");
            foreach (Carti item in lCarti)
            {
                Console.WriteLine("{0,20} - {1} ", item.denumire, item.aneditie);
            }
            Console.ReadLine();
        }

        private static void Sortare(List<Carti> lCarti)
        {
            try
            {
                lCarti.Sort((c2, c1) => string.Compare(c1.denumire, c2.denumire));

            }
            catch (Exception)
            {

                Console.WriteLine("Eroare");
            }    
        }
    }
}
