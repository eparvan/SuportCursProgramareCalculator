﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AplicatiaMere
{
    /*În grădina lui Ion creşte un măr. În măr există n mere, numerotate distinct de la 1 la n. 
Pomul fiind fermecat, merele cad din el după o regulă diferită de legile fizicii.
La un moment dat mărul 1 se desprinde de pe ramura sa şi începe să cadă vertical în jos. 
Dacă în timpul căderii un măr atinge un alt măr, acesta din urmă începe să cadă şi el vertical în jos. 
Traiectoria merelor în cădere nu se schimbă la atingerea altor mere. 
Astfel, orice măr, cu excepţia primului, începe să cadă doar după ce a fost atins de un măr în cădere.

Cerinţă

Scrieţi un program care să determine numărul de mere care vor cădea din pom.

Date de intrare

Fişierul de intrare mere.in va conţine pe prima linie numărul natural n al merelor din pom. 
Următoarele n linii conţin descrierea merelor.
Linia i+1 conţine descrierea mărului cu indicele i.
Fiecare măr este considerat o sferă. Un măr este descris prin 4 numere întregi separate prin spaţii: coordonatele (xi, yi, zi) ale punctului său cel mai de sus (în acest punct el este prins de ramură, codiţa fiind punctiformă) şi raza ri. Se garantează că iniţial oricare două mere nu se intersectează. Axa OZ este orientată vertical în sus.

Date de ieşire

Fişierul de ieşire mere.out va conţine o singură linie pe care va fi scris numărul merelor care vor cădea din pom.

Restricţii

1 ≤ N ≤ 200
-10000 ≤ (xi, yi, zi) ≤ 10000
1 ≤ ri ≤ 10000
     */
    class Program
    {
        static int[,] ma;
        static int n;
        static int[] u;
        static void Main(string[] args)
        {
            using (StreamReader fin = new StreamReader("mere.in"))
            {
                n = int.Parse(fin.ReadLine());
                string[] linie;
                ma = new int[n, n];
                int[] x = new int[n];
                int[] y = new int[n];
                int[] z = new int[n];
                int[] r = new int[n];
                for (int i = 0; i < n; i++)
                {
                    linie = fin.ReadLine().Split(' ');
                    x[i] = int.Parse(linie[0]);
                    y[i] = int.Parse(linie[1]);
                    z[i] = int.Parse(linie[2]);
                    r[i] = int.Parse(linie[3]);
                    z[i] = z[i] - r[i];
                }
                //Formarea matricii de adiacenta
                for (int i = 0; i < n; i++)
                {
                    for (int j = 0; j < n; j++)
                    {
                        if (Math.Pow((x[i]-x[j]),2)+Math.Pow((y[i]-y[j]),2)<=Math.Pow((r[i]+r[j]),2) && z[j]<z[i])
                        {
                            ma[i, j] = 1;
                        }
                    }
                }

            }
            Console.WriteLine("matricea de adiacenta:");
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    Console.Write("{0} ", ma[i, j]);
                }
                Console.WriteLine();
            }
            
            int rez = 0;
            u = new int[n];
            Find(0);
            for (int i = 0; i < n; i++)
            {
                if (u[i]==1)
                {
                    rez++;
                }
            }
            using (StreamWriter fout = new StreamWriter("mere.out"))
            {
                fout.WriteLine(rez);
            }
            Console.WriteLine("Vor cadea {0} mere", rez);
            Console.ReadKey();
        }
        private static void Find(int x)
        {
            u[x] = 1;
            for (int i = 0; i < n; i++)
            {
                if (ma[x,i]==1 && u[i]!=1)
                {
                    Find(i);
                }
            }
        }
    }
}
