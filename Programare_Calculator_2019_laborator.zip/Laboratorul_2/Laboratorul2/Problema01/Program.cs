﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problema01
{
    /*Problema 1.
     * De creat o lista unidirectionala cu elemente de tip intreg, completata in mod aleatoriu.
     * Numarul de elemente din lista sa fie citit de la tastatura.
     * Sa  se formeze o listă din  elementelor divizibile la 4 și să se determine suma lor.
     */
    class Program
    {
        static void Main(string[] args)
        {
            bool f = true;
            while (f)
            {
                try
                {
                    Console.Clear();
                    //Citim numarul de elemente n
                    Console.Write("Numarul de elemente al listei: n= ");
                    int n = int.Parse(Console.ReadLine()); //Daca n este gresit se arunca exceptie
                    Random el = new Random();
                    //Declaram lista "listaNumere"
                    List<int> listaNumere = new List<int>();
                    for (int i = 0; i < n; i++)
                    {
                        listaNumere.Add(el.Next(100));
                    }
                    Console.WriteLine("Lista de numere initiala:");
                    TiparesteLista(listaNumere);
                    List<int> listaDivPatru = new List<int>();
                    listaDivPatru = CreareListaDivPatru(listaNumere);
                    Console.WriteLine("\nLista de numere divizibile la patru:");
                    TiparesteLista(listaDivPatru);
                    Console.WriteLine("\nSuma elementelor divizibile la 4 este egala cu: {0}", SumaDivPatru(listaNumere));
                    f = false;
                }
                catch (Exception)
                {

                    Console.WriteLine("Date gresite!");
                }
                Console.ReadKey();
            }
            
            
        }
        //Metoda de crearea a listei in dependenta de conditie
        private static List<int> CreareListaDivPatru(List<int> listaNumere)
        {
            List<int> lista = new List<int>();
            foreach (int numar in listaNumere)
            {
                if (numar % 4 == 0 && numar!=0)
                {
                    lista.Add(numar);
                }
            }
            return lista;
        }

        //Metoda ce determina suma elementelor divizibila la 4
        private static int SumaDivPatru(List<int> listaNumere)
        {
            int suma = 0;
            foreach (int numar in listaNumere)
            {
                if (numar % 4 ==0)
                {
                    suma = suma + numar;
                }
            }
            return suma;
        }

        //Metoda de tiparire a elementelor listei la ecran
        private static void TiparesteLista(List<int> listaNumere)
        {
            foreach (int numar in listaNumere)
            {
                Console.Write("{0} ", numar);
            }
        }
    }
}
