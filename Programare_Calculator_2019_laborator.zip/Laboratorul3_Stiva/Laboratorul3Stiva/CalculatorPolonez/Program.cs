﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorPolonez
{
    /*
Evaluarea unei expresii în notatie poloneza
Notatia poloneza (sau postfix) este un mod de scriere a expresiilor, în care ordinea operatorilor si a operanzilor este schimbata fata de cea dintr-o expresie uzuala.

În notatia uzuala (numita si infix) o expresie are forma: 
operand operator operand

În notatia postfix (poloneza) expresia este scrisa sub forma: 
operand operand operator

De exemplu:

a + b devine în notatie poloneza a b +

(a - b) * c devine a b - c *

a - b * (c + d) devine a b c d + * -

Avantajul notatiei poloneze este acela ca indica ordinea corecta a evaluarii operatiilor 
fara a utiliza paranteze. Astfel, o expresie poloneza poate fi evaluata printr-o singura parcurgere a sa.

Pentru evaluarea unei expresii în notatie poloneza se poate folosi o stiva de valori reale. 
Ori de câte ori întâlnim în expresie un operand, valoarea lui este introdusa în stiva. 
Daca întâlnim un operator atunci se extrag doua valori din vârful stivei, care sunt, 
de fapt, cei doi operanzi, aplicam operatorul asupra valorilor extrase si rezultatul 
îl depunem în stiva. În momentul în care s-a terminat parcurgerea expresiei, 
rezultatul final al expresiei este în vârful stivei (si stiva contine doar aceasta valoare).


     */
    class Program
    {
        static void Main(string[] args)
        {
            //Din linia de consolă citim un șir de caractere
            //pe care îl divizăm după spațiu într-un masiv de caractere.
            //Datele se întroduc cît timp nu va fi introdus cuvîntul „quit”
            while (true)
            {
                Console.Write("Introdu datele > ");
                string input = Console.ReadLine();
                //sirul introdus se transformă în litere mici și se verifică dacă nu este cuvîntul „quit”
                if (input.Trim().ToLower() == "quit")
                {
                    break; //dacă este „quit” ieșim din repetare
                }
                // Formăm stiva valorilor neprelucrate.
                Stack<int> values = new Stack<int>();

                foreach (string token in input.Split(new char[] { ' ' }))
                {
                    // Dacă valoarea este un număr întreg ...
                    int value;
                    if (int.TryParse(token, out value))
                    {
                        // ... este depusă pe stivă.
                        values.Push(value);
                    }
                    else
                    {
                        if (values.Count != 0)
                        {
                            // în caz contrar se execută operația ...
                            int rhs = values.Pop(); //operandul drept
                            int lhs = values.Pop(); //operandul stîng

                            // ... și rezultatul se pune înapoi pe stivă.
                            switch (token)
                            {
                                case "+": //adunarea
                                    values.Push(lhs + rhs);
                                    break;
                                case "-": //scăderea
                                    values.Push(lhs - rhs);
                                    break;
                                case "*": //înmulțirea
                                    values.Push(lhs * rhs);
                                    break;
                                case "/": //împărțirea
                                    values.Push(lhs / rhs);
                                    break;
                                case "%"://restul de la împărțire
                                    values.Push(lhs % rhs);
                                    break;
                                default:
                                    // Dacă nu este nici un operator +, -, *, /, %
                                    Console.WriteLine("Semn necunoscut: {0}", token);
                                    break;
                            }
                        }
                        else
                            Console.WriteLine("Stiva nu are nici un operand!");

                    }
                }

                // Ultimul element din stivă și este rezultatul.
                if (values.Count != 0)
                {
                    Console.WriteLine(values.Pop());
                }
                else
                    Console.WriteLine("Calcule nu pot fi efectuate!");
                
            }
        }
    }
}
