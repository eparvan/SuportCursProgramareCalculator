﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RadicalOrdinN
{
    /*Calculam radical de ordin n
     */
    class Program
    {
        static void Main(string[] args)
        {
            int n;
            Console.Write("n=");
            n = int.Parse(Console.ReadLine());
            double valoare;
            Console.Write("valoare=");
            valoare = double.Parse(Console.ReadLine());
            Console.WriteLine("Radacina de ordinul {0} din {1} este {2}", n, valoare, RadacinaDivide(0, Math.Sqrt(valoare), n, valoare));
            Console.ReadKey();
        }

        private static object RadacinaDivide(double s, double d, int n, double valoare)
        {
            double eps = 1e-12;
            if (d-s<=eps)
            {
                return s;
            }
            else
            {
                double m = (s + d) / 2;
                if (Putere(m, n, valoare) == 0)
                {
                    return m;
                }
                else
                    if (Putere(m, n, valoare) < 0)
                {
                    return RadacinaDivide(m, d, n, valoare);
                }
                else
                    return RadacinaDivide(s,m,n,valoare);
            }
        }

        private static double Putere(double y, int n, double valoare)
        {
            double p = 1;
            for (int i = 0; i < n; i++)
            {
                p = p * y;
            }
            return p - valoare;
        }
    }
}
