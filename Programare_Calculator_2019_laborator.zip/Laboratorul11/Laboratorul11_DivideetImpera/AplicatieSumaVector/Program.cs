﻿using System;


namespace AplicatieSumaVector
{
    /*Suma elementelor unui vector prin metoda Divide Et Impera
     */
    class Program
    {
        static void Main(string[] args)
        {
            int n;
            Console.Write("n=");
            n = int.Parse(Console.ReadLine());
            int[] vector = new int[n];
            Random element = new Random();
            for (int i = 0; i < n; i++)
            {
                vector[i] = element.Next(1, 10);
            }
            DisplayVector(vector);
            Console.WriteLine("\n-------------------------------");
            Console.WriteLine("\nSuma elementelor acestui vector este egala cu: {0}", 
                SumaDivide(vector,0,n-1));
            Console.ReadKey();
        }

        private static int SumaDivide(int[] vector, int li, int ls)
        {
            int mijloc, left, right;
            if (li != ls)
            {
                mijloc = (li + ls) / 2;
                left = SumaDivide(vector, li, mijloc);
                right = SumaDivide(vector, mijloc + 1, ls);
                return left + right;
            }
            else
                return vector[li];
        }

        private static void DisplayVector(int[] vector)
        {
            Console.WriteLine("Elementele vectorului: ");
            foreach (int element in vector)
            {
                Console.Write("{0} ", element);
            }
        }
    }
}
