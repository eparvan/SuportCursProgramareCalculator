﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AplicatieFactorial
{
    /*Calculul factorialului prin metoda Divide et Impera
     */
    class Program
    {
        //static void Main(string[] args)
        //{
        //    Console.Write("n=");
        //    int n = int.Parse(Console.ReadLine());
        //    Console.WriteLine("{0}! = {1}", n, Factorial(1, n));
        //    Console.ReadKey();
        //}

        //private static int Factorial(int p, int q)
        //{
        //    int r;
        //    if (p > q)
        //    {
        //        return 1;
        //    }
        //    r = (p + q) / 2;
        //    return r * Factorial(p, r - 1) * Factorial(r + 1, q);
        //}
        //Sarcina de laborator
        /*
         *1.	Tratați excepțiile la întroducerea datelor;
          2.	Modifcați aplicația astfel încît rezultatul 
          să fie maximum din 19 cifre, iar dacă intervalul 
          este depășit, să se afișeze mesajul corespunzător.
 
         */
        static void Main(string[] args)
        {
            while (true)
            {
                try
                {
                    Console.Clear();
                    Console.Write("n=");
                    ulong n = ulong.Parse(Console.ReadLine());
                    if (Factorial(1, n) != 0)
                    {
                        Console.WriteLine("{0}! = {1}", n, Factorial(1, n));
                        Console.Write("Doriti sa iesiti din aplicatie? tastati d/n: ");
                        string go = Console.ReadLine();
                        if (go == "d")
                        {
                            break;
                        }
                        Console.ReadKey();
                    }
                    else
                    {
                        Console.WriteLine("Numarul este prea mare pentru a calcula factorialul !");
                        Console.ReadKey();
                    }

                }
                catch (Exception)
                {
                    Console.WriteLine("Numarul introdus este incorect");
                    Console.ReadKey();
                }
            }

        }

        private static ulong Factorial(ulong p, ulong q)
        {
            ulong mijloc;
            ulong rezultat;
            if (p > q)
            {
                return 1;
            }
            mijloc = (p + q) / 2;
            rezultat = mijloc * Factorial(p, mijloc - 1) * Factorial(mijloc + 1, q);
            if (rezultat > ulong.MaxValue / 2)
            {
                return 0;
            }
            return rezultat;
        }
    }
}
