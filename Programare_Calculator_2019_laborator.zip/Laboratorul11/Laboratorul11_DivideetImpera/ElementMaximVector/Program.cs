﻿using System;

namespace ElementMaximVector
{/*Folosind Tehnica Divide Et Impera, sa se determine elementul maxim dintr-un vector
    */
    class Program
    {
        static void Main(string[] args)
        {
            int n;
            Console.Write("n=");
            n = int.Parse(Console.ReadLine());
            int[] vector = new int[n];
            Random element = new Random();
            for (int i = 0; i < n; i++)
            {
                vector[i] = element.Next(1, 10);
            }
            DisplayVector(vector);
            Console.WriteLine("\n-------------------------------");
            Console.WriteLine("\nElementul maximal este: {0}", MaxDivide(vector, 0, n - 1));
            Console.ReadKey();
        }
        private static void DisplayVector(int[] vector)
        {
            Console.WriteLine("Elementele vectorului: ");
            foreach (int element in vector)
            {
                Console.Write("{0} ", element);
            }
        }
        private static int MaxDivide(int[] vector, int left, int right)
        {
            int els, eld, mijloc;
            if (left == right)
            {
                return vector[left]; //conditia de baza
            }
            else
                //Divizarea vectorului
                mijloc = (left + right) / 2;
            els = MaxDivide(vector,left, mijloc);
            eld = MaxDivide(vector, mijloc+1, right);
            //Combinarea soluțiilor
            if (els > eld)
            {
                return els;
            }
            else
                return eld;
        }
    }
}
