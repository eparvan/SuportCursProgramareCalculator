﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AplicatieAvioane
{
    /*
     * Avioanele care solicită aterizarea pe o anumită pistă a unui aeroport 
     * formează un fir de așteptare. 
     * Elaboraţi un program care citește de la tastatură și afi șează pe ecran datele 
     * despre fiecare avion care solicită aterizarea și avionul care aterizează. 
     * Datele în studiu includ: 
     * – numărul de înmatriculare (integer); 
     * – tipul avionului (string); 
     * – numărul rutei (integer).
     */
   
    class Program
    {
        //Tipul de date struct va contine informatia despre avion
        public struct Avion
        {
            public int numarInmatriculare;
            public string tipAvion;
            public int numarRuta;
        }

        //Metoda pentru introducerea datelor în coada pentru aterizare
        
       public static Queue<Avion> IntroduDatele(Queue<Avion> coadaAvioane)
       {
            Console.Clear();
            Avion dateAvion;
            Console.Write("Numarul de inmatriculare: ");
            dateAvion.numarInmatriculare = int.Parse(Console.ReadLine());
            Console.Write("Tipul avionului: ");
            dateAvion.tipAvion = Console.ReadLine();
            Console.Write("Numarul rutei: ");
            dateAvion.numarRuta = int.Parse(Console.ReadLine());
            coadaAvioane.Enqueue(dateAvion);//avionul este adaugat in coada pentru aterizare
            return coadaAvioane;
       }
        public static Queue<Avion> AfisareAvion(Queue<Avion> coadaAvioane)
        {
            Console.Clear();
            Console.WriteLine("Datele avionului ce aterizeaza:");
            Avion avion = coadaAvioane.Dequeue();//extragem avionul ce a aterizat din virful cozii
            Console.WriteLine("Numarul de inmatriculare: {0}", avion.numarInmatriculare);
            Console.WriteLine("Tipul avionului: {0}", avion.tipAvion);
            Console.WriteLine("Numarul rutei: {0}", avion.numarRuta);
            return coadaAvioane; //reintoarcem coada avioanelor modificata

        }
        public static void AfisareCoada(Queue<Avion> coadaAvioane)
        {
            Console.Clear();
            Console.WriteLine("Coada avioaneleor la aterizare este formata din {0} avioane:", coadaAvioane.Count);
            int i = 0;
            foreach (var avion in coadaAvioane)
            {
                i++;
                Console.WriteLine("Avionul {0}:\tNumar inmatriculare - {1} :" +
                    "Tip avion - {2} :" +
                    "Numar ruta - {3} ",i, avion.numarInmatriculare, avion.tipAvion, avion.numarRuta );
            }
        }
        //Metoda ce va afisa meniul aplicatiei
        public static int ShowMenu()
        {
            int userChoose_int = 0;
            bool ok;
            do
            {
                Console.WriteLine("1. Introdu datele: ");
                Console.WriteLine("2. Afiseaza datele: ");
                Console.WriteLine("3. Afiseaza COADA: " );
                Console.WriteLine("0. Iesire");
                string userChoose = Console.ReadLine();
                ok = int.TryParse(userChoose, out userChoose_int);
                if (!ok)
                {
                    Console.WriteLine("Nu exista astfel de optiune!");
                }
            } while (!ok);
            return userChoose_int;
        }
        static void Main(string[] args)
        {
            Queue<Avion> coadaAvioane = new Queue<Avion>();//Declaram structura ce va contine coada avioanelor la aterizare
            bool go = true;
            do
            {
                int userChoose = ShowMenu();
                switch (userChoose)
                {
                    case 1: Console.WriteLine("Introdu datele:\n");
                        coadaAvioane = IntroduDatele(coadaAvioane);//se formeaza coada avioanelor la aterizare
                        break;
                    case 2: Console.WriteLine("Afiseaza datele:\n");
                        coadaAvioane = AfisareAvion(coadaAvioane);//afisam informatia desre avionul ce a aterizat
                        break;
                    case 3: Console.WriteLine("Afiseaza coada:");
                        AfisareCoada(coadaAvioane);//Afisam coada avioanelor ce asteapta aterizarea
                            break;
                    case 0: go=false;
                        Console.WriteLine("Iesire");
                        break;
                    default:
                        Console.WriteLine("nu exista astfel de optiune!");
                        break;
                }
            } while (go);

            Console.ReadKey();
        }
    }
}
