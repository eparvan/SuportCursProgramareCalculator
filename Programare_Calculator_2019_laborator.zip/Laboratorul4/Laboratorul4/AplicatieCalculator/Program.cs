﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AplicatieCalculator
{
    /*De elaborat o aplicatie ce va gestiona calculatoarele dintr-un depozit 
     * ce functionaeaza ca o banda rulanta 
     * ce contine informatia despre denumirea calculatorului și volumul de memorie RAM.
     * Aplicatia va avea următoarele funcționalități:
     * - introducerea calculatorului în depozit;
     * - extragerea calculatorului din depozit și afisarea informatiei despre acest calculator;
     * - afisarea informatiei despre toate calculatorele din depozit și volumul
     * total de memorie operativă;
     * 
     */
    class Program
    {
        public struct Computer
        {
            public string denumireComputer;
            public int volumMemorie;
        }
        //Metoda ce va afisa meniul aplicatiei
        public static int ShowMenu()
        {
            int userChoose_int = 0;
            bool ok;
            do
            {
                Console.WriteLine("1. Introdu datele: ");
                Console.WriteLine("2. Afiseaza datele calculatorului: ");
                Console.WriteLine("3. Afiseaza continutul depozitului: ");
                Console.WriteLine("0. Iesire");
                string userChoose = Console.ReadLine();
                ok = int.TryParse(userChoose, out userChoose_int);
                if (!ok)
                {
                    Console.WriteLine("Nu exista astfel de optiune!");
                }
            } while (!ok);
            return userChoose_int;
        }
        static void Main(string[] args)
        {
            Queue<Computer> coadaComputer = new Queue<Computer>();
            //Declaram structura ce va contine coada computerilor de pe banda rulanta
            bool go = true;
            do
            {
                int userChoose = ShowMenu();
                switch (userChoose)
                {
                    case 1:
                        Console.WriteLine("Introdu datele:\n");
                        coadaComputer = IntroduDatele(coadaComputer);//se formeaza coada computerelor din depozit
                        break;
                    case 2:
                        Console.WriteLine("Afiseaza datele:\n");
                        coadaComputer = AfisareComputer(coadaComputer);//afisam informatia desre computerul extras
                        break;
                    case 3:
                        Console.WriteLine("Afiseaza coada:");
                        AfisareCoada(coadaComputer);//Afisam coada computerelor ce asteapta extragerea
                        break;
                    case 0:
                        go = false;
                        Console.WriteLine("Iesire");
                        break;
                    default:
                        Console.WriteLine("nu exista astfel de optiune!");
                        break;
                }
            } while (go);

            Console.ReadKey();
        }

        private static void AfisareCoada(Queue<Computer> coadaComputer)
        {
            Console.Clear();
            if (coadaComputer.Count != 0)
            {


                Console.WriteLine("Computere pe banda rulanta sunt: {0}", coadaComputer.Count);
                int i = 0;
                int memorieTotal = 0;
                foreach (var computer in coadaComputer)
                {
                    i++;
                    memorieTotal += computer.volumMemorie;
                    Console.WriteLine("Computerul {0}:\tDenumire computer - {1} :" +
                                      "Volum memorie RAM - {2} ", i, computer.denumireComputer, 
                                      computer.volumMemorie);
                }
                Console.WriteLine("Volumul total de memorie RAM este : {0}", memorieTotal);
            }
            else
                Console.WriteLine("In depozit lipsesc computere!");
        }

        private static Queue<Computer> AfisareComputer(Queue<Computer> coadaComputer)
        {
            Console.Clear();
            if (coadaComputer.Count != 0)
            {


                Console.WriteLine("Datele computerului extras din depozit:");
                Computer computer = coadaComputer.Dequeue();//extragem computerul de pe banda rulanta
                Console.WriteLine("Denumire computer: {0}", computer.denumireComputer);
                Console.WriteLine("Volumul memoriei RAM: {0}", computer.volumMemorie);

                
            }
            else
                Console.WriteLine("In depozit lipsesc computere!");
            return coadaComputer;//reintoarcem coda computerelor modificata
        }

        private static Queue<Computer> IntroduDatele(Queue<Computer> coadaComputer)
        {
            Console.Clear();
            Computer dateComputer;
            Console.Write("Denumirea computerului: ");
            dateComputer.denumireComputer = Console.ReadLine();
            Console.Write("Volumul memoriei RAM: ");
            dateComputer.volumMemorie = int.Parse(Console.ReadLine());
            
            coadaComputer.Enqueue(dateComputer);//
            return coadaComputer;
        }
    }
}
